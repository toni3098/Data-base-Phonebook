﻿namespace PhoneBook1
{


    partial class Phonebook_LabDataSet
    {
        partial class ДействиеDataTable
        {
        }
    }
}

namespace PhoneBook1.Phonebook_LabDataSetTableAdapters {
    
    
    public partial class ПользовательTableAdapter {
    }
}
