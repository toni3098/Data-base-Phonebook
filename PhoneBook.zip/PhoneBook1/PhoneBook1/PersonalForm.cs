﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PhoneBook1
{
    public partial class PersonalForm : Form
    {
        public PersonalForm()
        {
            InitializeComponent();
        }

        private static PersonalForm p;
        public static PersonalForm pd
        {
            get
            {
                if (p == null || p.IsDisposed)
                {
                    p = new PersonalForm();
                }
                return p;
            }
        }

        private void персоналBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.персоналBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.phonebook_LabDataSet);

        }

        private void персоналBindingNavigatorSaveItem_Click_1(object sender, EventArgs e)
        {
            try
            {
                this.Validate();
                this.персоналBindingSource.EndEdit();
                this.tableAdapterManager.UpdateAll(this.phonebook_LabDataSet);
            }
            catch (Exception err)
            {
                MessageBox.Show(err.Message, "Ошибка", MessageBoxButtons.OK,
                    MessageBoxIcon.Error);
            }

        }

        private void PersonalForm_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'phonebook_LabDataSet.Персонал' table. You can move, or remove it, as needed.
            this.персоналTableAdapter.Fill(this.phonebook_LabDataSet.Персонал);

        }

        private void toolStripLabel1_Click(object sender, EventArgs e)
        {

        }


        private void toolStripButtonFind_Click(object sender, EventArgs e)
        {
            if (toolStripTextBoxFind.Text == "")
            {
                MessageBox.Show("Вы ничего не задали", "Внимание",
               MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }
            int indexPos;
            try
            {
                indexPos =
               персоналBindingSource.Find(GetSelectedFieldName(),
               toolStripTextBoxFind.Text);
            }
            catch (Exception err)
            {
                MessageBox.Show("Ошибка поиска \n" + err.Message);
                return;
            }
            if (indexPos > -1)
                персоналBindingSource.Position = indexPos;
            else
            {
                MessageBox.Show("Таких сотрудников нет", "Внимание",
               MessageBoxButtons.OK, MessageBoxIcon.Information);
                персоналBindingSource.Position = 0;
            }

        }

        string GetSelectedFieldName()
        {
            return
           персоналDataGridView.Columns[персоналDataGridView.CurrentCell.ColumnIndex
           ].DataPropertyName;
        }

        private void checkBoxFind_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBoxFind.Checked)
            {
                if (toolStripTextBoxFind.Text == "")
                    MessageBox.Show("Вы ничего не задали", "Внимание",
                   MessageBoxButtons.OK, MessageBoxIcon.Information);
                else
                    try
                    {
                        персоналBindingSource.Filter =
                       GetSelectedFieldName() + "='" + toolStripTextBoxFind.Text + "'";
                    }
                    catch (Exception err)
                    {
                        MessageBox.Show("Ошибка фильтрации \n" + err.Message);
                    }
            }
            else
                персоналBindingSource.Filter = "";
            if (персоналBindingSource.Count == 0)
            {
                MessageBox.Show("Нет таких");
                персоналBindingSource.Filter = "";
                checkBoxFind.Checked = false;
            }
        }

        private void toolStripTextBoxFind_Click(object sender, EventArgs e)
        {

        }

        private void toolStripButtonOK_Click(object sender, EventArgs e)
        {
            DialogResult = DialogResult.OK;
        }

        //переменная для текущего(выбранного) ID персонал
        int idCurrent = -1;
        public int ShowSelectForm(int id)
        {
            toolStripButtonOK.Visible = true;
            idCurrent = id;
            if (ShowDialog() == DialogResult.OK)
                return
               (int)((DataRowView)персоналBindingSource.Current)["ID_Персонал"];
            else
                return -1;
        }

        private void PersonalForm_Shown(object sender, EventArgs e)
        {
            персоналBindingSource.Position = персоналBindingSource.Find("ID_Персонал", idCurrent);
        }

        public void ShowForm()
        {
            toolStripButtonOK.Visible = false;
            персоналBindingSource.Position = 0;
            Show();
            Activate();
        }

    }
}
