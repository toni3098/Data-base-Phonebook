﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.IO;
using System.Data.Common;

namespace PhoneBook1
{
    public partial class FormSQL : Form
    {
        public FormSQL()
        {
            InitializeComponent();
        }

        private void FormSQL_Load(object sender, EventArgs e)
        {

        }

        //объявляем метод, на вход подаем строку запроса, а возвращаем объект DataTable
        DataTable FillDataGridView(string sqlSelect)
        {
            //Создаем объект connection класса SqlConnection для соединения с БД
            //CafeConnectionString – строка описания соединения с источником данных

             SqlConnection connection = new
            SqlConnection(Properties.Settings.Default.Phonebook_LabConnectionString);
            //Создаем объект command для SQL команды
            SqlCommand command = connection.CreateCommand();
            //Заносим текст SQL запроса через параметр sqlSelect
            command.CommandText = sqlSelect;
            //Создаем объект adapter класса SqlDataAdapter
            SqlDataAdapter adapter = new SqlDataAdapter();
            //Задаем адаптеру нужную команду, в данном случае команду Select
            adapter.SelectCommand = command;
            //Создаем объект table для последующего отображения результата запроса
             DataTable table = new DataTable();
            //заполним набор данных результатом запроса
            adapter.Fill(table);
            return table;
        }

        private static FormSQL s;
        public static FormSQL sd
        {
            get
            {
                if (s == null || s.IsDisposed)
                {
                    s = new FormSQL();
                }
                return s;
            }
        }

        public void ShowForm()
        {
            Show();
            Activate();
        }

        private void radioButtonWorkers_CheckedChanged(object sender, EventArgs e)
        {
            dataGridView.DataSource = FillDataGridView("SELECT * FROM Персонал");
        }

        private void radioButtonContact_CheckedChanged(object sender, EventArgs e)
        {
            dataGridView.DataSource = 
                FillDataGridView
                (@"SELECT ID_Контакт, ID_Персо, Персонал.ФИО_Пер AS ФИО FROM Контакт INNER JOIN Персонал ON Контакт.ID_Персо = Персонал.ID_Персонал");
        }

        private void radioButtonUsers_CheckedChanged(object sender, EventArgs e)
        {
            dataGridView.DataSource = FillDataGridView("SELECT ID_Пользователь, " +
                "ФИО_Польз+'-'+Паспорт AS Паспорт, Телефон AS Телефон, " +
                "'Active' AS Статус FROM Пользователь");
        }

        private void radioButtonHistory_CheckedChanged(object sender, EventArgs e)
        {
            dataGridView.DataSource = FillDataGridView("SELECT * FROM Действие");
        }

        private void buttonF_select_Click(object sender, EventArgs e)
        {
            if (String.IsNullOrEmpty(textBoxWorker.Text))
            {
                MessageBox.Show("Обязательно укажите фамилию необходимого сотрудника.\nДопустим ввод первых символов.", "Внимание", MessageBoxButtons.OK,
               MessageBoxIcon.Warning);
                return;
            }

            string sqlSelect = "";
            if (radioButtonDet_User.Checked)
                sqlSelect = @"SELECT Персонал.ID_Персонал, Персонал.ФИО_Пер AS Персонал, 
Пользователь.ID_Пользователь, Пользователь.ФИО_Польз AS Пользователь, Пользователь.Паспорт
FROM     Персонал INNER JOIN Пользователь ON Персонал.ID_Пользователь = 
Пользователь.ID_Пользователь WHERE Персонал.ФИО_Пер LIKE @name";
            else
            if (radioButtonDet_action.Checked)
                sqlSelect = @"SELECT Персонал.ID_Персонал, Персонал.ФИО_Пер, Действие.ID_Действие, 
Действие.Операция, Действие.ID_Контакт, Действие.ID_Пользователь
FROM     Персонал INNER JOIN Действие ON Персонал.ID_Персонал = 
Действие.ID_Персонал WHERE Персонал.ФИО_Пер LIKE @name";

            if (checkBoxOrder.Checked)
                sqlSelect += " ORDER BY Действие.ID_Действие DESC";
            SqlConnection connection = new
           SqlConnection(Properties.Settings.Default.Phonebook_LabConnectionString);
            SqlCommand command = connection.CreateCommand();
            command.CommandText = sqlSelect;
            command.Parameters.AddWithValue("@name", textBoxWorker.Text +
           "%");
            SqlDataAdapter adapter = new SqlDataAdapter();
            adapter.SelectCommand = command;
            DataTable table = new DataTable();
            adapter.Fill(table);
            dataGridViewFSelect.DataSource = table;
            if (table.Rows.Count == 0) MessageBox.Show("Нет значений!",
           "Информация", MessageBoxButtons.OK, MessageBoxIcon.Information);

        }

        private void checkBoxOrder_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void buttonSubquery_Click(object sender, EventArgs e)
        {
            {
                if (String.IsNullOrEmpty(textBoxNumber.Text))
                {
                    MessageBox.Show("Обязательно укажите номер необходимой продажи",
                   "Внимание", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }
                string sqlSelect = "";

                if (radioButtonCorrelated.Checked)
                {
                    sqlSelect = @"SELECT ID_Пользователь AS ID, ФИО_Польз AS ФИО, Паспорт , 
Телефон , Фото , Адрес FROM Пользователь WHERE ID_Пользователь = @number";
                }

                else
                {
                    if (radioButtonNoCorrelated.Checked)
                        sqlSelect = @"SELECT Пользователь.ID_Пользователь, Пользователь.ФИО_Польз, 
Пользователь.Паспорт, Действие.ID_Действие, Действие.ID_Контакт, Действие.Операция
FROM     Пользователь INNER JOIN
                  Действие ON Пользователь.ID_Пользователь = Действие.ID_Пользователь
WHERE Пользователь.ID_Пользователь = @number";
                    else
                    {
                        MessageBox.Show("Не выбрали вид подзапроса", "Ошибка", MessageBoxButtons.OK, 
                            MessageBoxIcon.Error);
                        return;
                    }
                }

                SqlConnection connection = 
                    new SqlConnection(Properties.Settings.Default.Phonebook_LabConnectionString);
                SqlCommand command = connection.CreateCommand();
                command.CommandText = sqlSelect;
                try
                {
                    command.Parameters.Add("@number", SqlDbType.Int).Value = 
                        int.Parse(textBoxNumber.Text);
                }
                catch
                {
                    MessageBox.Show("ID контакта в условии должен быть задан числом", 
                        "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }
                SqlDataAdapter adapter = new SqlDataAdapter();
                adapter.SelectCommand = command;
                DataTable table = new DataTable();
                adapter.Fill(table);
                dataGridViewSubquery.DataSource = table;
                if (table.Rows.Count == 0)
                {
                    MessageBox.Show("Нет значений!", "Информация", MessageBoxButtons.OK, 
                        MessageBoxIcon.Information);

                }
            }
        }
        string fileImage = "";
        private void buttonOpenPhoto_user_Click(object sender, EventArgs e)
        {
            openFileDialogUser.Title = "Укажите файл для фото";
            if (openFileDialogUser.ShowDialog() == DialogResult.OK)
            {
                fileImage = openFileDialogUser.FileName;
                try
                {
                    pictureBoxPhoto_user.Load(openFileDialogUser.FileName);
                }
                catch
                {
                    MessageBox.Show("Выбран не тот формат файла", "Ошибка",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }
            }
            else fileImage = "";
        }


        void InsertUser()
        {
            if (String.IsNullOrEmpty(textBox_user.Text) ||
           (String.IsNullOrEmpty(textBoxName_user.Text) ||
           (String.IsNullOrEmpty(textBoxPassport_user.Text) ||
           (String.IsNullOrEmpty(comboBoxGenre_user.Text)) ||
           (String.IsNullOrEmpty(textBoxPhone_user.Text)) ||(String.IsNullOrEmpty(textBoxAdress_user.Text)))))
            {
                MessageBox.Show("Обязательно введите ID пользователя, ФИО, паспорт, пол и телефон", "Внимание", 
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
            return;
            }
            int id;
            if (!int.TryParse(textBox_user.Text, out id))
            {
                MessageBox.Show("Некоректное значение ID пользователя!", "Внимание ID",
               MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            double telephon = 0;
            if (!double.TryParse(textBoxPhone_user.Text, out telephon))
            {
                MessageBox.Show("Некоректный номер", "Внимание номер",
               MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            
            if (!String.IsNullOrEmpty(textBoxName_user.Text))
            {
                MessageBox.Show("Внимание ФИО", "Пустой", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            else
            {
                string name = textBoxName_user.Text;
            }

            if (!String.IsNullOrEmpty(textBoxAdress_user.Text))
            {
                MessageBox.Show("Внимание Адрес", "Пустой", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            else
            {
                string adress = textBoxAdress_user.Text;
            }

            if (!String.IsNullOrEmpty(comboBoxGenre_user.Text))
            {
                MessageBox.Show("Внимание пол", "Пустой", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            else
            {
                string genre = comboBoxGenre_user.Text;
            }
            
            if (!String.IsNullOrEmpty(textBoxPassport_user.Text))
            {
                MessageBox.Show("Внимание паспорт", "Пустой", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            else
            {
                string passport = textBoxPassport_user.Text;
            }

            string sqlInsert = @"INSERT INTO Пользователь (ID_Пользователь, ФИО_Польз, Телефон,
Паспорт, , Пол, Адрес, Фото)
 VALUES (@id, @name, @telephon, @passport, @genre, @adress,@Photo)";
            SqlConnection connection = new
           SqlConnection(Properties.Settings.Default.Phonebook_LabConnectionString);
            connection.Open();
            SqlCommand command = connection.CreateCommand();
            command.CommandText = sqlInsert;
            command.Parameters.AddWithValue("@id", id);
            command.Parameters.AddWithValue("@name", textBoxName_user.Text);
            //или другим способом, если необходимо явное указание типа данных
            command.Parameters.Add("@telephon", SqlDbType.NVarChar).Value =
           textBoxPhone_user.Text;
            command.Parameters.AddWithValue("@adress", textBoxAdress_user.Text);
            command.Parameters.AddWithValue("@passport", textBoxPassport_user.Text);
            command.Parameters.AddWithValue("@genre", comboBoxGenre_user.Text);
            
            if (!String.IsNullOrEmpty(fileImage))
                command.Parameters.AddWithValue("@Photo", File.ReadAllBytes(fileImage));
            else
            {
                command.Parameters.Add("@Photo", SqlDbType.VarBinary);
                command.Parameters["@Photo"].Value = DBNull.Value;
            }
            //command.Parameters.AddWithValue("@telephon", telephon);
            try
            {
                command.ExecuteNonQuery();
            }
            catch (Exception err)
            {
                MessageBox.Show("Ошибка выполнения запроса.\n" + err.Message,
               "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            connection.Close();
            buttonSelect_Click(this, EventArgs.Empty);
        }

        private void buttonSelect_Click(object sender, EventArgs e)
        {
            dataGridViewUser.DataSource = FillDataGridView("SELECT * FROM Пользователь");
 DataGridViewImageColumn column =
(DataGridViewImageColumn)dataGridViewUser.Columns["Фото"];
            column.ImageLayout = DataGridViewImageCellLayout.Stretch;
        }

        void UpdateUser()
        {
            if (String.IsNullOrEmpty(textBox_user.Text))
            {
                MessageBox.Show("Обязательно укажите код блюда, для которого будете менять данные", "Внимание", MessageBoxButtons.OK,
               MessageBoxIcon.Warning);
                return;
            }
            int id;
            if (!int.TryParse(textBox_user.Text, out id))
            {
                MessageBox.Show("Некоректное значение ID пользователя!", "Внимание",
               MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            double telephon = 0;
            if (!double.TryParse(textBoxPhone_user.Text, out telephon))
            {
                MessageBox.Show("Некоректный номер", "Внимание",
               MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            
            if (!String.IsNullOrEmpty(textBoxName_user.Text))
            {
                MessageBox.Show("Внимание", "Пустой", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            else
            {
                string name = textBoxName_user.Text;
            }

            if (!String.IsNullOrEmpty(textBoxName_user.Text))
            {
                MessageBox.Show("Внимание", "Пустой", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            else
            {
                string adress = textBoxAdress_user.Text;
            }
            
            if (!String.IsNullOrEmpty(comboBoxGenre_user.Text))
            {
                MessageBox.Show("Внимание", "Пустой", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            else
            {
                string genre = comboBoxGenre_user.Text;
            }
            
            if (!String.IsNullOrEmpty(textBoxPassport_user.Text))
            {
                MessageBox.Show("Внимание", "Пустой", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            else
            {
                string passport = textBoxPassport_user.Text;
            }
            string sqlUpdate = "UPDATE Пользователь WHERE ID_Пользователь = @id";
 SqlConnection connection = new
SqlConnection(Properties.Settings.Default.Phonebook_LabConnectionString);
            connection.Open();
            SqlCommand command = connection.CreateCommand();
            string sqlValues = "";
            if (!String.IsNullOrEmpty(textBoxName_user.Text))
                sqlValues += "ФИО_Польз=@name,";
            if (!String.IsNullOrEmpty(textBoxPhone_user.Text))
                sqlValues += "Телефон=@telephon,";
            if (!String.IsNullOrEmpty(textBoxAdress_user.Text))
                sqlValues += "Адрес=@adress,";
            if (!String.IsNullOrEmpty(comboBoxGenre_user.Text))
                sqlValues += "Пол=@genre,";
            if (!String.IsNullOrEmpty(textBoxPassport_user.Text))
                sqlValues += "Паспорт=@passport,";
            if (!String.IsNullOrEmpty(fileImage))
                sqlValues += "Фото=@Photo,";
            command.CommandText = String.Format(sqlUpdate, sqlValues);
            if (!String.IsNullOrEmpty(textBoxName_user.Text))
                command.Parameters.AddWithValue("@name", textBoxName_user.Text);
            //или другим способом, если необходимо явное указание типа данных
            if (!String.IsNullOrEmpty(textBoxPhone_user.Text))
                command.Parameters.Add("@telephon", SqlDbType.NVarChar).Value =
               textBoxPhone_user.Text;
            if (!String.IsNullOrEmpty(textBoxAdress_user.Text))
                command.Parameters.AddWithValue("@adress", textBoxAdress_user);
            if (!String.IsNullOrEmpty(textBoxPassport_user.Text))
                command.Parameters.AddWithValue("@passport", textBoxPassport_user);
            if (!String.IsNullOrEmpty(comboBoxGenre_user.Text))
                command.Parameters.AddWithValue("@genre", comboBoxGenre_user.Text);
            if (!String.IsNullOrEmpty(fileImage))
                command.Parameters.AddWithValue("@Photo",
               File.ReadAllBytes(fileImage));
            if (!String.IsNullOrEmpty(textBox_user.Text))
                command.Parameters.AddWithValue("@id", id);
            try
            {
                command.ExecuteNonQuery();
            }
            catch (Exception err)
            {
                MessageBox.Show("Ошибка выполнения запроса:\n" + err.Message,
               "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            connection.Close();
            buttonSelect_Click(this, EventArgs.Empty);
        }

        void DeleteUser()
        {
            if (String.IsNullOrEmpty(textBox_user.Text))
            {
                MessageBox.Show("Обязательно укажите код блюда данные которого необходимо удалить", 
                    "Внимание", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            return;
            }
            int id;
            if (!int.TryParse(textBox_user.Text, out id))
            {
                MessageBox.Show("Некоректное значение кода блюда!", "Внимание",
               MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            string sqlDelete = @"DELETE FROM Блюда WHERE ID_Пользователь = @id";
            SqlConnection connection = new
           SqlConnection(Properties.Settings.Default.Phonebook_LabConnectionString);
            connection.Open();
            SqlCommand command = connection.CreateCommand();
            command.CommandText = sqlDelete;
            command.Parameters.AddWithValue("@id", id);
            try
            {
                command.ExecuteNonQuery();
            }
            catch (Exception err)
            {
                MessageBox.Show(err.Message, "Ошибка удаления");
            }
            connection.Close();
            buttonSelect_Click(this, EventArgs.Empty);
        }

        private void radioButtonDelete_user_CheckedChanged(object sender, EventArgs e)
        {
            panelUser.Visible = !radioButtonDelete_user.Checked;
        }

        private void buttonExecuteDML_Click(object sender, EventArgs e)
        {
            if (radioButtonInsert_user.Checked)
                InsertUser();
            else
            if (radioButtonUpdate_user.Checked)
                UpdateUser();
            else
            if (radioButtonDelete_user.Checked)
                DeleteUser();
            else
                MessageBox.Show("Вы не выбрали действие", "Внимание",
               MessageBoxButtons.OK, MessageBoxIcon.Warning);
        }
    }
}
