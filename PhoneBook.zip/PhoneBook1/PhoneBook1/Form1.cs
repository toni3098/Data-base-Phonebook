﻿using PhoneBook1.Properties;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PhoneBook1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void выходToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void оПрограммеToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("(C)ТУСУР, КБЭВС, ЗАФИТУМБУ АНТОНИО, г.581, 2023", "О программе",
                MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            e.Cancel = MessageBox.Show("Вы хотите закрыть программу ?", "Внимание",
                MessageBoxButtons.YesNo, MessageBoxIcon.Question) != DialogResult.Yes;
        }

        private void toolStripButton1_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void toolStripButton2_Click(object sender, EventArgs e)
        {
            MessageBox.Show("(C)ТУСУР, КСУП, ЗАФИТУМБУ АНТОНИО, г.581, 2023", "О программе",
                MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void Form1_FormClosed(object sender, FormClosedEventArgs e)
        {
            Settings.Default.Save();
        }

        private void пользовательToolStripMenuItem_Click(object sender, EventArgs e)
        {
            UserForm.fd.ShowForm();
        }

        private void контактToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ConctactForm.cd.ShowForm();
        }

        private void сотрудникиToolStripMenuItem_Click(object sender, EventArgs e)
        {
            PersonalForm.pd.ShowForm(); 
        }

        private void действиеToolStripMenuItem_Click(object sender, EventArgs e)
        {
            OperationFormcs.od.ShowForm();
        }

        private void контактToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            ConctactForm.cd.ShowForm();
        }

        private void sQLToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            FormSQL.sd.ShowForm();
        }
    }
}
