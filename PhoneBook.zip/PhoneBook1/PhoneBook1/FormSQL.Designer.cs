﻿namespace PhoneBook1
{
    partial class FormSQL
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tabControlSQL = new System.Windows.Forms.TabControl();
            this.tabPagePrimer = new System.Windows.Forms.TabPage();
            this.groupBoxSelect = new System.Windows.Forms.GroupBox();
            this.dataGridView = new System.Windows.Forms.DataGridView();
            this.radioButtonHistory = new System.Windows.Forms.RadioButton();
            this.radioButtonUsers = new System.Windows.Forms.RadioButton();
            this.radioButtonContact = new System.Windows.Forms.RadioButton();
            this.radioButtonWorkers = new System.Windows.Forms.RadioButton();
            this.tabPageSelect = new System.Windows.Forms.TabPage();
            this.groupBoxFSelect = new System.Windows.Forms.GroupBox();
            this.dataGridViewFSelect = new System.Windows.Forms.DataGridView();
            this.buttonF_Select = new System.Windows.Forms.Button();
            this.checkBoxOrder = new System.Windows.Forms.CheckBox();
            this.groupBoxDet = new System.Windows.Forms.GroupBox();
            this.radioButtonDet_NO = new System.Windows.Forms.RadioButton();
            this.radioButtonDet_action = new System.Windows.Forms.RadioButton();
            this.radioButtonDet_User = new System.Windows.Forms.RadioButton();
            this.textBoxWorker = new System.Windows.Forms.TextBox();
            this.labelWorker = new System.Windows.Forms.Label();
            this.tabPageSubquery = new System.Windows.Forms.TabPage();
            this.groupBoxSubquery = new System.Windows.Forms.GroupBox();
            this.dataGridViewSubquery = new System.Windows.Forms.DataGridView();
            this.buttonSubquery = new System.Windows.Forms.Button();
            this.textBoxNumber = new System.Windows.Forms.TextBox();
            this.labelNumber = new System.Windows.Forms.Label();
            this.radioButtonNoCorrelated = new System.Windows.Forms.RadioButton();
            this.radioButtonCorrelated = new System.Windows.Forms.RadioButton();
            this.tabPageDML = new System.Windows.Forms.TabPage();
            this.groupBoxDML = new System.Windows.Forms.GroupBox();
            this.dataGridViewUser = new System.Windows.Forms.DataGridView();
            this.buttonSelect = new System.Windows.Forms.Button();
            this.buttonExecuteDML = new System.Windows.Forms.Button();
            this.panelUser = new System.Windows.Forms.Panel();
            this.buttonOpenPhoto_user = new System.Windows.Forms.Button();
            this.labelPhoto_user = new System.Windows.Forms.Label();
            this.pictureBoxPhoto_user = new System.Windows.Forms.PictureBox();
            this.textBoxAdress_user = new System.Windows.Forms.TextBox();
            this.labelAdress_user = new System.Windows.Forms.Label();
            this.comboBoxGenre_user = new System.Windows.Forms.ComboBox();
            this.textBoxPhone_user = new System.Windows.Forms.TextBox();
            this.labelPhone_user = new System.Windows.Forms.Label();
            this.labelGenre_user = new System.Windows.Forms.Label();
            this.textBoxPassport_user = new System.Windows.Forms.TextBox();
            this.labelPasseport_user = new System.Windows.Forms.Label();
            this.textBoxName_user = new System.Windows.Forms.TextBox();
            this.labelName_user = new System.Windows.Forms.Label();
            this.textBox_user = new System.Windows.Forms.TextBox();
            this.labelId_user = new System.Windows.Forms.Label();
            this.radioButtonDelete_user = new System.Windows.Forms.RadioButton();
            this.radioButtonUpdate_user = new System.Windows.Forms.RadioButton();
            this.radioButtonInsert_user = new System.Windows.Forms.RadioButton();
            this.openFileDialogUser = new System.Windows.Forms.OpenFileDialog();
            this.tabControlSQL.SuspendLayout();
            this.tabPagePrimer.SuspendLayout();
            this.groupBoxSelect.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView)).BeginInit();
            this.tabPageSelect.SuspendLayout();
            this.groupBoxFSelect.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewFSelect)).BeginInit();
            this.groupBoxDet.SuspendLayout();
            this.tabPageSubquery.SuspendLayout();
            this.groupBoxSubquery.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewSubquery)).BeginInit();
            this.tabPageDML.SuspendLayout();
            this.groupBoxDML.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewUser)).BeginInit();
            this.panelUser.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxPhoto_user)).BeginInit();
            this.SuspendLayout();
            // 
            // tabControlSQL
            // 
            this.tabControlSQL.Controls.Add(this.tabPagePrimer);
            this.tabControlSQL.Controls.Add(this.tabPageSelect);
            this.tabControlSQL.Controls.Add(this.tabPageSubquery);
            this.tabControlSQL.Controls.Add(this.tabPageDML);
            this.tabControlSQL.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabControlSQL.Location = new System.Drawing.Point(0, 0);
            this.tabControlSQL.Name = "tabControlSQL";
            this.tabControlSQL.SelectedIndex = 0;
            this.tabControlSQL.Size = new System.Drawing.Size(1063, 798);
            this.tabControlSQL.TabIndex = 0;
            // 
            // tabPagePrimer
            // 
            this.tabPagePrimer.Controls.Add(this.groupBoxSelect);
            this.tabPagePrimer.Location = new System.Drawing.Point(4, 25);
            this.tabPagePrimer.Name = "tabPagePrimer";
            this.tabPagePrimer.Padding = new System.Windows.Forms.Padding(3);
            this.tabPagePrimer.Size = new System.Drawing.Size(1055, 769);
            this.tabPagePrimer.TabIndex = 0;
            this.tabPagePrimer.Text = "Примеры запросов";
            // 
            // groupBoxSelect
            // 
            this.groupBoxSelect.Controls.Add(this.dataGridView);
            this.groupBoxSelect.Controls.Add(this.radioButtonHistory);
            this.groupBoxSelect.Controls.Add(this.radioButtonUsers);
            this.groupBoxSelect.Controls.Add(this.radioButtonContact);
            this.groupBoxSelect.Controls.Add(this.radioButtonWorkers);
            this.groupBoxSelect.Dock = System.Windows.Forms.DockStyle.Top;
            this.groupBoxSelect.Location = new System.Drawing.Point(3, 3);
            this.groupBoxSelect.Name = "groupBoxSelect";
            this.groupBoxSelect.Size = new System.Drawing.Size(1049, 412);
            this.groupBoxSelect.TabIndex = 0;
            this.groupBoxSelect.TabStop = false;
            this.groupBoxSelect.Text = "Запросы по данным";
            // 
            // dataGridView
            // 
            this.dataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView.Location = new System.Drawing.Point(7, 64);
            this.dataGridView.Name = "dataGridView";
            this.dataGridView.RowHeadersWidth = 51;
            this.dataGridView.RowTemplate.Height = 24;
            this.dataGridView.Size = new System.Drawing.Size(776, 354);
            this.dataGridView.TabIndex = 4;
            // 
            // radioButtonHistory
            // 
            this.radioButtonHistory.AutoSize = true;
            this.radioButtonHistory.Location = new System.Drawing.Point(352, 22);
            this.radioButtonHistory.Name = "radioButtonHistory";
            this.radioButtonHistory.Size = new System.Drawing.Size(147, 20);
            this.radioButtonHistory.TabIndex = 3;
            this.radioButtonHistory.TabStop = true;
            this.radioButtonHistory.Text = "История действия";
            this.radioButtonHistory.UseVisualStyleBackColor = true;
            this.radioButtonHistory.CheckedChanged += new System.EventHandler(this.radioButtonHistory_CheckedChanged);
            // 
            // radioButtonUsers
            // 
            this.radioButtonUsers.AutoSize = true;
            this.radioButtonUsers.Location = new System.Drawing.Point(223, 22);
            this.radioButtonUsers.Name = "radioButtonUsers";
            this.radioButtonUsers.Size = new System.Drawing.Size(123, 20);
            this.radioButtonUsers.TabIndex = 2;
            this.radioButtonUsers.TabStop = true;
            this.radioButtonUsers.Text = "Пользователь";
            this.radioButtonUsers.UseVisualStyleBackColor = true;
            this.radioButtonUsers.CheckedChanged += new System.EventHandler(this.radioButtonUsers_CheckedChanged);
            // 
            // radioButtonContact
            // 
            this.radioButtonContact.AutoSize = true;
            this.radioButtonContact.Location = new System.Drawing.Point(122, 22);
            this.radioButtonContact.Name = "radioButtonContact";
            this.radioButtonContact.Size = new System.Drawing.Size(81, 20);
            this.radioButtonContact.TabIndex = 1;
            this.radioButtonContact.TabStop = true;
            this.radioButtonContact.Text = "Контакт";
            this.radioButtonContact.UseVisualStyleBackColor = true;
            this.radioButtonContact.CheckedChanged += new System.EventHandler(this.radioButtonContact_CheckedChanged);
            // 
            // radioButtonWorkers
            // 
            this.radioButtonWorkers.AutoSize = true;
            this.radioButtonWorkers.Location = new System.Drawing.Point(7, 22);
            this.radioButtonWorkers.Name = "radioButtonWorkers";
            this.radioButtonWorkers.Size = new System.Drawing.Size(93, 20);
            this.radioButtonWorkers.TabIndex = 0;
            this.radioButtonWorkers.TabStop = true;
            this.radioButtonWorkers.Text = "Персонал";
            this.radioButtonWorkers.UseVisualStyleBackColor = true;
            this.radioButtonWorkers.CheckedChanged += new System.EventHandler(this.radioButtonWorkers_CheckedChanged);
            // 
            // tabPageSelect
            // 
            this.tabPageSelect.Controls.Add(this.groupBoxFSelect);
            this.tabPageSelect.Location = new System.Drawing.Point(4, 25);
            this.tabPageSelect.Name = "tabPageSelect";
            this.tabPageSelect.Padding = new System.Windows.Forms.Padding(3);
            this.tabPageSelect.Size = new System.Drawing.Size(1055, 769);
            this.tabPageSelect.TabIndex = 1;
            this.tabPageSelect.Text = "Полная запись SELECT";
            this.tabPageSelect.UseVisualStyleBackColor = true;
            // 
            // groupBoxFSelect
            // 
            this.groupBoxFSelect.Controls.Add(this.dataGridViewFSelect);
            this.groupBoxFSelect.Controls.Add(this.buttonF_Select);
            this.groupBoxFSelect.Controls.Add(this.checkBoxOrder);
            this.groupBoxFSelect.Controls.Add(this.groupBoxDet);
            this.groupBoxFSelect.Controls.Add(this.textBoxWorker);
            this.groupBoxFSelect.Controls.Add(this.labelWorker);
            this.groupBoxFSelect.Dock = System.Windows.Forms.DockStyle.Top;
            this.groupBoxFSelect.Location = new System.Drawing.Point(3, 3);
            this.groupBoxFSelect.Name = "groupBoxFSelect";
            this.groupBoxFSelect.Size = new System.Drawing.Size(1049, 613);
            this.groupBoxFSelect.TabIndex = 0;
            this.groupBoxFSelect.TabStop = false;
            this.groupBoxFSelect.Text = "Прибыль сотрудников";
            // 
            // dataGridViewFSelect
            // 
            this.dataGridViewFSelect.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewFSelect.Location = new System.Drawing.Point(4, 222);
            this.dataGridViewFSelect.Name = "dataGridViewFSelect";
            this.dataGridViewFSelect.RowHeadersWidth = 51;
            this.dataGridViewFSelect.RowTemplate.Height = 24;
            this.dataGridViewFSelect.Size = new System.Drawing.Size(1011, 399);
            this.dataGridViewFSelect.TabIndex = 7;
            // 
            // buttonF_Select
            // 
            this.buttonF_Select.Image = global::PhoneBook1.Properties.Resources._92d5b4c8801403478d1c54dbac59c7d71;
            this.buttonF_Select.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.buttonF_Select.Location = new System.Drawing.Point(410, 165);
            this.buttonF_Select.Name = "buttonF_Select";
            this.buttonF_Select.Size = new System.Drawing.Size(252, 51);
            this.buttonF_Select.TabIndex = 6;
            this.buttonF_Select.Text = "Действие персоналов";
            this.buttonF_Select.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.buttonF_Select.UseVisualStyleBackColor = true;
            this.buttonF_Select.Click += new System.EventHandler(this.buttonF_select_Click);
            // 
            // checkBoxOrder
            // 
            this.checkBoxOrder.AutoSize = true;
            this.checkBoxOrder.Location = new System.Drawing.Point(35, 100);
            this.checkBoxOrder.Name = "checkBoxOrder";
            this.checkBoxOrder.Size = new System.Drawing.Size(322, 20);
            this.checkBoxOrder.TabIndex = 4;
            this.checkBoxOrder.Text = "Включить сортировку по убыванию прибыли";
            this.checkBoxOrder.UseVisualStyleBackColor = true;
            this.checkBoxOrder.CheckedChanged += new System.EventHandler(this.checkBoxOrder_CheckedChanged);
            // 
            // groupBoxDet
            // 
            this.groupBoxDet.Controls.Add(this.radioButtonDet_NO);
            this.groupBoxDet.Controls.Add(this.radioButtonDet_action);
            this.groupBoxDet.Controls.Add(this.radioButtonDet_User);
            this.groupBoxDet.Location = new System.Drawing.Point(715, 21);
            this.groupBoxDet.Name = "groupBoxDet";
            this.groupBoxDet.Size = new System.Drawing.Size(300, 114);
            this.groupBoxDet.TabIndex = 2;
            this.groupBoxDet.TabStop = false;
            this.groupBoxDet.Text = " Детализация действий персоналов";
            // 
            // radioButtonDet_NO
            // 
            this.radioButtonDet_NO.AutoSize = true;
            this.radioButtonDet_NO.Location = new System.Drawing.Point(27, 79);
            this.radioButtonDet_NO.Name = "radioButtonDet_NO";
            this.radioButtonDet_NO.Size = new System.Drawing.Size(143, 20);
            this.radioButtonDet_NO.TabIndex = 2;
            this.radioButtonDet_NO.TabStop = true;
            this.radioButtonDet_NO.Text = "Нет детализации";
            this.radioButtonDet_NO.UseVisualStyleBackColor = true;
            // 
            // radioButtonDet_action
            // 
            this.radioButtonDet_action.AutoSize = true;
            this.radioButtonDet_action.Location = new System.Drawing.Point(27, 53);
            this.radioButtonDet_action.Name = "radioButtonDet_action";
            this.radioButtonDet_action.Size = new System.Drawing.Size(178, 20);
            this.radioButtonDet_action.TabIndex = 1;
            this.radioButtonDet_action.TabStop = true;
            this.radioButtonDet_action.Text = "Прибыль по действиям";
            this.radioButtonDet_action.UseVisualStyleBackColor = true;
            // 
            // radioButtonDet_User
            // 
            this.radioButtonDet_User.AutoSize = true;
            this.radioButtonDet_User.Location = new System.Drawing.Point(27, 27);
            this.radioButtonDet_User.Name = "radioButtonDet_User";
            this.radioButtonDet_User.Size = new System.Drawing.Size(210, 20);
            this.radioButtonDet_User.TabIndex = 0;
            this.radioButtonDet_User.TabStop = true;
            this.radioButtonDet_User.Text = "Прибыль по пользователям";
            this.radioButtonDet_User.UseVisualStyleBackColor = true;
            // 
            // textBoxWorker
            // 
            this.textBoxWorker.Location = new System.Drawing.Point(202, 47);
            this.textBoxWorker.Name = "textBoxWorker";
            this.textBoxWorker.Size = new System.Drawing.Size(254, 22);
            this.textBoxWorker.TabIndex = 1;
            // 
            // labelWorker
            // 
            this.labelWorker.AutoSize = true;
            this.labelWorker.Location = new System.Drawing.Point(32, 50);
            this.labelWorker.Name = "labelWorker";
            this.labelWorker.Size = new System.Drawing.Size(140, 16);
            this.labelWorker.TabIndex = 0;
            this.labelWorker.Text = "Фамилия персонала";
            // 
            // tabPageSubquery
            // 
            this.tabPageSubquery.Controls.Add(this.groupBoxSubquery);
            this.tabPageSubquery.Location = new System.Drawing.Point(4, 25);
            this.tabPageSubquery.Name = "tabPageSubquery";
            this.tabPageSubquery.Padding = new System.Windows.Forms.Padding(3);
            this.tabPageSubquery.Size = new System.Drawing.Size(1055, 769);
            this.tabPageSubquery.TabIndex = 2;
            this.tabPageSubquery.Text = "Примеры подзапросов";
            this.tabPageSubquery.UseVisualStyleBackColor = true;
            // 
            // groupBoxSubquery
            // 
            this.groupBoxSubquery.Controls.Add(this.dataGridViewSubquery);
            this.groupBoxSubquery.Controls.Add(this.buttonSubquery);
            this.groupBoxSubquery.Controls.Add(this.textBoxNumber);
            this.groupBoxSubquery.Controls.Add(this.labelNumber);
            this.groupBoxSubquery.Controls.Add(this.radioButtonNoCorrelated);
            this.groupBoxSubquery.Controls.Add(this.radioButtonCorrelated);
            this.groupBoxSubquery.Dock = System.Windows.Forms.DockStyle.Top;
            this.groupBoxSubquery.Location = new System.Drawing.Point(3, 3);
            this.groupBoxSubquery.Name = "groupBoxSubquery";
            this.groupBoxSubquery.Size = new System.Drawing.Size(1049, 614);
            this.groupBoxSubquery.TabIndex = 0;
            this.groupBoxSubquery.TabStop = false;
            this.groupBoxSubquery.Text = "Подзапросы по данным";
            // 
            // dataGridViewSubquery
            // 
            this.dataGridViewSubquery.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewSubquery.Location = new System.Drawing.Point(-3, 181);
            this.dataGridViewSubquery.Name = "dataGridViewSubquery";
            this.dataGridViewSubquery.RowHeadersWidth = 51;
            this.dataGridViewSubquery.RowTemplate.Height = 24;
            this.dataGridViewSubquery.Size = new System.Drawing.Size(1024, 440);
            this.dataGridViewSubquery.TabIndex = 5;
            // 
            // buttonSubquery
            // 
            this.buttonSubquery.Image = global::PhoneBook1.Properties.Resources.execute;
            this.buttonSubquery.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.buttonSubquery.Location = new System.Drawing.Point(409, 114);
            this.buttonSubquery.Name = "buttonSubquery";
            this.buttonSubquery.Size = new System.Drawing.Size(238, 51);
            this.buttonSubquery.TabIndex = 4;
            this.buttonSubquery.Text = "Выполнить подзапрос";
            this.buttonSubquery.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.buttonSubquery.UseVisualStyleBackColor = true;
            this.buttonSubquery.Click += new System.EventHandler(this.buttonSubquery_Click);
            // 
            // textBoxNumber
            // 
            this.textBoxNumber.Location = new System.Drawing.Point(359, 76);
            this.textBoxNumber.Name = "textBoxNumber";
            this.textBoxNumber.Size = new System.Drawing.Size(324, 22);
            this.textBoxNumber.TabIndex = 3;
            // 
            // labelNumber
            // 
            this.labelNumber.AutoSize = true;
            this.labelNumber.Location = new System.Drawing.Point(176, 79);
            this.labelNumber.Name = "labelNumber";
            this.labelNumber.Size = new System.Drawing.Size(83, 16);
            this.labelNumber.TabIndex = 2;
            this.labelNumber.Text = "ID контакта";
            // 
            // radioButtonNoCorrelated
            // 
            this.radioButtonNoCorrelated.AutoSize = true;
            this.radioButtonNoCorrelated.Location = new System.Drawing.Point(607, 33);
            this.radioButtonNoCorrelated.Name = "radioButtonNoCorrelated";
            this.radioButtonNoCorrelated.Size = new System.Drawing.Size(240, 20);
            this.radioButtonNoCorrelated.TabIndex = 1;
            this.radioButtonNoCorrelated.TabStop = true;
            this.radioButtonNoCorrelated.Text = "Некоррелированный подзапроc";
            this.radioButtonNoCorrelated.UseVisualStyleBackColor = true;
            // 
            // radioButtonCorrelated
            // 
            this.radioButtonCorrelated.AutoSize = true;
            this.radioButtonCorrelated.Location = new System.Drawing.Point(179, 33);
            this.radioButtonCorrelated.Name = "radioButtonCorrelated";
            this.radioButtonCorrelated.Size = new System.Drawing.Size(223, 20);
            this.radioButtonCorrelated.TabIndex = 0;
            this.radioButtonCorrelated.TabStop = true;
            this.radioButtonCorrelated.Text = "Коррелированный подзапрос";
            this.radioButtonCorrelated.UseVisualStyleBackColor = true;
            // 
            // tabPageDML
            // 
            this.tabPageDML.Controls.Add(this.groupBoxDML);
            this.tabPageDML.Location = new System.Drawing.Point(4, 25);
            this.tabPageDML.Name = "tabPageDML";
            this.tabPageDML.Padding = new System.Windows.Forms.Padding(3);
            this.tabPageDML.Size = new System.Drawing.Size(1055, 769);
            this.tabPageDML.TabIndex = 3;
            this.tabPageDML.Text = "Запросы изменения данных";
            this.tabPageDML.UseVisualStyleBackColor = true;
            // 
            // groupBoxDML
            // 
            this.groupBoxDML.Controls.Add(this.dataGridViewUser);
            this.groupBoxDML.Controls.Add(this.buttonSelect);
            this.groupBoxDML.Controls.Add(this.buttonExecuteDML);
            this.groupBoxDML.Controls.Add(this.panelUser);
            this.groupBoxDML.Controls.Add(this.textBox_user);
            this.groupBoxDML.Controls.Add(this.labelId_user);
            this.groupBoxDML.Controls.Add(this.radioButtonDelete_user);
            this.groupBoxDML.Controls.Add(this.radioButtonUpdate_user);
            this.groupBoxDML.Controls.Add(this.radioButtonInsert_user);
            this.groupBoxDML.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBoxDML.Location = new System.Drawing.Point(3, 3);
            this.groupBoxDML.Name = "groupBoxDML";
            this.groupBoxDML.Size = new System.Drawing.Size(1049, 763);
            this.groupBoxDML.TabIndex = 0;
            this.groupBoxDML.TabStop = false;
            this.groupBoxDML.Text = "Операторы";
            // 
            // dataGridViewUser
            // 
            this.dataGridViewUser.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewUser.Location = new System.Drawing.Point(6, 431);
            this.dataGridViewUser.Name = "dataGridViewUser";
            this.dataGridViewUser.RowHeadersWidth = 51;
            this.dataGridViewUser.RowTemplate.Height = 24;
            this.dataGridViewUser.Size = new System.Drawing.Size(1046, 339);
            this.dataGridViewUser.TabIndex = 8;
            // 
            // buttonSelect
            // 
            this.buttonSelect.Image = global::PhoneBook1.Properties.Resources.list;
            this.buttonSelect.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.buttonSelect.Location = new System.Drawing.Point(436, 371);
            this.buttonSelect.Name = "buttonSelect";
            this.buttonSelect.Size = new System.Drawing.Size(281, 54);
            this.buttonSelect.TabIndex = 7;
            this.buttonSelect.Text = "Показать список пользователя";
            this.buttonSelect.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.buttonSelect.UseVisualStyleBackColor = true;
            this.buttonSelect.Click += new System.EventHandler(this.buttonSelect_Click);
            // 
            // buttonExecuteDML
            // 
            this.buttonExecuteDML.Image = global::PhoneBook1.Properties.Resources.sql_server;
            this.buttonExecuteDML.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.buttonExecuteDML.Location = new System.Drawing.Point(483, 66);
            this.buttonExecuteDML.Name = "buttonExecuteDML";
            this.buttonExecuteDML.Size = new System.Drawing.Size(173, 34);
            this.buttonExecuteDML.TabIndex = 6;
            this.buttonExecuteDML.Text = "Выполнить запрос";
            this.buttonExecuteDML.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.buttonExecuteDML.UseVisualStyleBackColor = true;
            this.buttonExecuteDML.Click += new System.EventHandler(this.buttonExecuteDML_Click);
            // 
            // panelUser
            // 
            this.panelUser.Controls.Add(this.buttonOpenPhoto_user);
            this.panelUser.Controls.Add(this.labelPhoto_user);
            this.panelUser.Controls.Add(this.pictureBoxPhoto_user);
            this.panelUser.Controls.Add(this.textBoxAdress_user);
            this.panelUser.Controls.Add(this.labelAdress_user);
            this.panelUser.Controls.Add(this.comboBoxGenre_user);
            this.panelUser.Controls.Add(this.textBoxPhone_user);
            this.panelUser.Controls.Add(this.labelPhone_user);
            this.panelUser.Controls.Add(this.labelGenre_user);
            this.panelUser.Controls.Add(this.textBoxPassport_user);
            this.panelUser.Controls.Add(this.labelPasseport_user);
            this.panelUser.Controls.Add(this.textBoxName_user);
            this.panelUser.Controls.Add(this.labelName_user);
            this.panelUser.Location = new System.Drawing.Point(-3, 106);
            this.panelUser.Name = "panelUser";
            this.panelUser.Size = new System.Drawing.Size(1052, 259);
            this.panelUser.TabIndex = 5;
            // 
            // buttonOpenPhoto_user
            // 
            this.buttonOpenPhoto_user.Location = new System.Drawing.Point(486, 223);
            this.buttonOpenPhoto_user.Name = "buttonOpenPhoto_user";
            this.buttonOpenPhoto_user.Size = new System.Drawing.Size(173, 29);
            this.buttonOpenPhoto_user.TabIndex = 13;
            this.buttonOpenPhoto_user.Text = "Открыть фото";
            this.buttonOpenPhoto_user.UseVisualStyleBackColor = true;
            this.buttonOpenPhoto_user.Click += new System.EventHandler(this.buttonOpenPhoto_user_Click);
            // 
            // labelPhoto_user
            // 
            this.labelPhoto_user.AutoSize = true;
            this.labelPhoto_user.Location = new System.Drawing.Point(500, 22);
            this.labelPhoto_user.Name = "labelPhoto_user";
            this.labelPhoto_user.Size = new System.Drawing.Size(137, 16);
            this.labelPhoto_user.TabIndex = 12;
            this.labelPhoto_user.Text = "Фото пользователя";
            // 
            // pictureBoxPhoto_user
            // 
            this.pictureBoxPhoto_user.Location = new System.Drawing.Point(486, 55);
            this.pictureBoxPhoto_user.Name = "pictureBoxPhoto_user";
            this.pictureBoxPhoto_user.Size = new System.Drawing.Size(173, 162);
            this.pictureBoxPhoto_user.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBoxPhoto_user.TabIndex = 11;
            this.pictureBoxPhoto_user.TabStop = false;
            // 
            // textBoxAdress_user
            // 
            this.textBoxAdress_user.Location = new System.Drawing.Point(82, 195);
            this.textBoxAdress_user.Name = "textBoxAdress_user";
            this.textBoxAdress_user.Size = new System.Drawing.Size(175, 22);
            this.textBoxAdress_user.TabIndex = 10;
            // 
            // labelAdress_user
            // 
            this.labelAdress_user.AutoSize = true;
            this.labelAdress_user.Location = new System.Drawing.Point(12, 198);
            this.labelAdress_user.Name = "labelAdress_user";
            this.labelAdress_user.Size = new System.Drawing.Size(47, 16);
            this.labelAdress_user.TabIndex = 9;
            this.labelAdress_user.Text = "Адрес";
            // 
            // comboBoxGenre_user
            // 
            this.comboBoxGenre_user.FormattingEnabled = true;
            this.comboBoxGenre_user.Items.AddRange(new object[] {
            "Male",
            "Female"});
            this.comboBoxGenre_user.Location = new System.Drawing.Point(82, 101);
            this.comboBoxGenre_user.Name = "comboBoxGenre_user";
            this.comboBoxGenre_user.Size = new System.Drawing.Size(175, 24);
            this.comboBoxGenre_user.TabIndex = 8;
            // 
            // textBoxPhone_user
            // 
            this.textBoxPhone_user.Location = new System.Drawing.Point(82, 148);
            this.textBoxPhone_user.Name = "textBoxPhone_user";
            this.textBoxPhone_user.Size = new System.Drawing.Size(175, 22);
            this.textBoxPhone_user.TabIndex = 7;
            // 
            // labelPhone_user
            // 
            this.labelPhone_user.AutoSize = true;
            this.labelPhone_user.Location = new System.Drawing.Point(12, 151);
            this.labelPhone_user.Name = "labelPhone_user";
            this.labelPhone_user.Size = new System.Drawing.Size(67, 16);
            this.labelPhone_user.TabIndex = 6;
            this.labelPhone_user.Text = "Телефон";
            // 
            // labelGenre_user
            // 
            this.labelGenre_user.AutoSize = true;
            this.labelGenre_user.Location = new System.Drawing.Point(12, 104);
            this.labelGenre_user.Name = "labelGenre_user";
            this.labelGenre_user.Size = new System.Drawing.Size(33, 16);
            this.labelGenre_user.TabIndex = 4;
            this.labelGenre_user.Text = "Пол";
            // 
            // textBoxPassport_user
            // 
            this.textBoxPassport_user.Location = new System.Drawing.Point(82, 55);
            this.textBoxPassport_user.Name = "textBoxPassport_user";
            this.textBoxPassport_user.Size = new System.Drawing.Size(175, 22);
            this.textBoxPassport_user.TabIndex = 3;
            // 
            // labelPasseport_user
            // 
            this.labelPasseport_user.AutoSize = true;
            this.labelPasseport_user.Location = new System.Drawing.Point(12, 58);
            this.labelPasseport_user.Name = "labelPasseport_user";
            this.labelPasseport_user.Size = new System.Drawing.Size(63, 16);
            this.labelPasseport_user.TabIndex = 2;
            this.labelPasseport_user.Text = "Паспорт";
            // 
            // textBoxName_user
            // 
            this.textBoxName_user.Location = new System.Drawing.Point(82, 16);
            this.textBoxName_user.Name = "textBoxName_user";
            this.textBoxName_user.Size = new System.Drawing.Size(175, 22);
            this.textBoxName_user.TabIndex = 1;
            // 
            // labelName_user
            // 
            this.labelName_user.AutoSize = true;
            this.labelName_user.Location = new System.Drawing.Point(12, 19);
            this.labelName_user.Name = "labelName_user";
            this.labelName_user.Size = new System.Drawing.Size(38, 16);
            this.labelName_user.TabIndex = 0;
            this.labelName_user.Text = "ФИО";
            // 
            // textBox_user
            // 
            this.textBox_user.Location = new System.Drawing.Point(128, 78);
            this.textBox_user.Name = "textBox_user";
            this.textBox_user.Size = new System.Drawing.Size(100, 22);
            this.textBox_user.TabIndex = 4;
            // 
            // labelId_user
            // 
            this.labelId_user.AutoSize = true;
            this.labelId_user.Location = new System.Drawing.Point(6, 81);
            this.labelId_user.Name = "labelId_user";
            this.labelId_user.Size = new System.Drawing.Size(116, 16);
            this.labelId_user.TabIndex = 3;
            this.labelId_user.Text = "ID пользователя";
            // 
            // radioButtonDelete_user
            // 
            this.radioButtonDelete_user.AutoSize = true;
            this.radioButtonDelete_user.Location = new System.Drawing.Point(662, 36);
            this.radioButtonDelete_user.Name = "radioButtonDelete_user";
            this.radioButtonDelete_user.Size = new System.Drawing.Size(375, 20);
            this.radioButtonDelete_user.TabIndex = 2;
            this.radioButtonDelete_user.TabStop = true;
            this.radioButtonDelete_user.Text = "Удалить данные по пользователю с заданным кодом";
            this.radioButtonDelete_user.UseVisualStyleBackColor = true;
            this.radioButtonDelete_user.CheckedChanged += new System.EventHandler(this.radioButtonDelete_user_CheckedChanged);
            // 
            // radioButtonUpdate_user
            // 
            this.radioButtonUpdate_user.AutoSize = true;
            this.radioButtonUpdate_user.Location = new System.Drawing.Point(271, 36);
            this.radioButtonUpdate_user.Name = "radioButtonUpdate_user";
            this.radioButtonUpdate_user.Size = new System.Drawing.Size(385, 20);
            this.radioButtonUpdate_user.TabIndex = 1;
            this.radioButtonUpdate_user.TabStop = true;
            this.radioButtonUpdate_user.Text = "Изменить данные по пользователю с заданным кодом";
            this.radioButtonUpdate_user.UseVisualStyleBackColor = true;
            // 
            // radioButtonInsert_user
            // 
            this.radioButtonInsert_user.AutoSize = true;
            this.radioButtonInsert_user.Location = new System.Drawing.Point(6, 36);
            this.radioButtonInsert_user.Name = "radioButtonInsert_user";
            this.radioButtonInsert_user.Size = new System.Drawing.Size(261, 20);
            this.radioButtonInsert_user.TabIndex = 0;
            this.radioButtonInsert_user.TabStop = true;
            this.radioButtonInsert_user.Text = "Добавить данные по пользователю";
            this.radioButtonInsert_user.UseVisualStyleBackColor = true;
            // 
            // openFileDialogUser
            // 
            this.openFileDialogUser.FileName = "openFileDialog1";
            // 
            // FormSQL
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1063, 798);
            this.Controls.Add(this.tabControlSQL);
            this.Name = "FormSQL";
            this.Text = "Запросы";
            this.Load += new System.EventHandler(this.FormSQL_Load);
            this.tabControlSQL.ResumeLayout(false);
            this.tabPagePrimer.ResumeLayout(false);
            this.groupBoxSelect.ResumeLayout(false);
            this.groupBoxSelect.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView)).EndInit();
            this.tabPageSelect.ResumeLayout(false);
            this.groupBoxFSelect.ResumeLayout(false);
            this.groupBoxFSelect.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewFSelect)).EndInit();
            this.groupBoxDet.ResumeLayout(false);
            this.groupBoxDet.PerformLayout();
            this.tabPageSubquery.ResumeLayout(false);
            this.groupBoxSubquery.ResumeLayout(false);
            this.groupBoxSubquery.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewSubquery)).EndInit();
            this.tabPageDML.ResumeLayout(false);
            this.groupBoxDML.ResumeLayout(false);
            this.groupBoxDML.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewUser)).EndInit();
            this.panelUser.ResumeLayout(false);
            this.panelUser.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxPhoto_user)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tabControlSQL;
        private System.Windows.Forms.TabPage tabPagePrimer;
        private System.Windows.Forms.TabPage tabPageSelect;
        private System.Windows.Forms.GroupBox groupBoxSelect;
        private System.Windows.Forms.RadioButton radioButtonUsers;
        private System.Windows.Forms.RadioButton radioButtonContact;
        private System.Windows.Forms.RadioButton radioButtonWorkers;
        private System.Windows.Forms.DataGridView dataGridView;
        private System.Windows.Forms.RadioButton radioButtonHistory;
        private System.Windows.Forms.GroupBox groupBoxFSelect;
        private System.Windows.Forms.Label labelWorker;
        private System.Windows.Forms.GroupBox groupBoxDet;
        private System.Windows.Forms.TextBox textBoxWorker;
        private System.Windows.Forms.RadioButton radioButtonDet_NO;
        private System.Windows.Forms.RadioButton radioButtonDet_action;
        private System.Windows.Forms.RadioButton radioButtonDet_User;
        private System.Windows.Forms.CheckBox checkBoxOrder;
        private System.Windows.Forms.Button buttonF_Select;
        private System.Windows.Forms.DataGridView dataGridViewFSelect;
        private System.Windows.Forms.TabPage tabPageSubquery;
        private System.Windows.Forms.GroupBox groupBoxSubquery;
        private System.Windows.Forms.TextBox textBoxNumber;
        private System.Windows.Forms.Label labelNumber;
        private System.Windows.Forms.RadioButton radioButtonNoCorrelated;
        private System.Windows.Forms.RadioButton radioButtonCorrelated;
        private System.Windows.Forms.DataGridView dataGridViewSubquery;
        private System.Windows.Forms.Button buttonSubquery;
        private System.Windows.Forms.TabPage tabPageDML;
        private System.Windows.Forms.GroupBox groupBoxDML;
        private System.Windows.Forms.Label labelId_user;
        private System.Windows.Forms.RadioButton radioButtonDelete_user;
        private System.Windows.Forms.RadioButton radioButtonUpdate_user;
        private System.Windows.Forms.RadioButton radioButtonInsert_user;
        private System.Windows.Forms.Panel panelUser;
        private System.Windows.Forms.TextBox textBox_user;
        private System.Windows.Forms.Label labelName_user;
        private System.Windows.Forms.Label labelGenre_user;
        private System.Windows.Forms.TextBox textBoxPassport_user;
        private System.Windows.Forms.Label labelPasseport_user;
        private System.Windows.Forms.TextBox textBoxName_user;
        private System.Windows.Forms.TextBox textBoxPhone_user;
        private System.Windows.Forms.Label labelPhone_user;
        private System.Windows.Forms.ComboBox comboBoxGenre_user;
        private System.Windows.Forms.TextBox textBoxAdress_user;
        private System.Windows.Forms.Label labelAdress_user;
        private System.Windows.Forms.Button buttonOpenPhoto_user;
        private System.Windows.Forms.Label labelPhoto_user;
        private System.Windows.Forms.PictureBox pictureBoxPhoto_user;
        private System.Windows.Forms.OpenFileDialog openFileDialogUser;
        private System.Windows.Forms.Button buttonExecuteDML;
        private System.Windows.Forms.DataGridView dataGridViewUser;
        private System.Windows.Forms.Button buttonSelect;
    }
}