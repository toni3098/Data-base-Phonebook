﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PhoneBook1
{
    public partial class OperationFormcs : Form
    {
        public OperationFormcs()
        {
            InitializeComponent();
        }

        private void действиеBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            try
            {
                this.Validate();
                this.действиеBindingSource.EndEdit();
                this.tableAdapterManager.UpdateAll(this.phonebook_LabDataSet);
            }
            catch (Exception err)
            {
                MessageBox.Show(err.Message, "Ошибка", MessageBoxButtons.OK,
                    MessageBoxIcon.Error);
            }

        }

        private void OperationFormcs_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'phonebook_LabDataSet.Действие' table. You can move, or remove it, as needed.
            this.действиеTableAdapter.Fill(this.phonebook_LabDataSet.Действие);

        }

        private static OperationFormcs o;
        public static OperationFormcs od
        {
            get
            {
                if (o == null || o.IsDisposed)
                {
                    o = new OperationFormcs();
                }
                return o;
            }
        }

        public void ShowForm()
        {
            Show();
            Activate();
        }

        private void действиеDataGridView_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }


        private void действиеDataGridView_CellFormatting
            (object sender, DataGridViewCellFormattingEventArgs e)
        {
            if ((действиеDataGridView.Rows[e.RowIndex].Cells[
                "dataGridViewTextBoxColumn4"].Value == null) || 
                (действиеDataGridView.Rows[e.RowIndex].Cells[
                    "dataGridViewTextBoxColumn4"].Value.ToString() == ""))
                e.CellStyle.BackColor = Color.LightGreen;
            else
            {
                if (действиеDataGridView.Rows[e.RowIndex].Cells[
                    "dataGridViewTextBoxColumn4"].Value.ToString() == "Read")
                    e.CellStyle.BackColor = Color.SkyBlue;
                else if (действиеDataGridView.Rows[e.RowIndex].Cells[
                    "dataGridViewTextBoxColumn4"].Value.ToString() == "Add")
                    e.CellStyle.BackColor = Color.WhiteSmoke;
                else if (действиеDataGridView.Rows[e.RowIndex].Cells[
                    "dataGridViewTextBoxColumn4"].Value.ToString() == "Modify")
                    e.CellStyle.BackColor = Color.YellowGreen;
                else if (действиеDataGridView.Rows[e.RowIndex].Cells[
                    "dataGridViewTextBoxColumn4"].Value.ToString() == "Delete")
                    e.CellStyle.BackColor = Color.MediumVioletRed;
                else
                    e.CellStyle.BackColor = Color.Pink;
            }
        }
    }
}
