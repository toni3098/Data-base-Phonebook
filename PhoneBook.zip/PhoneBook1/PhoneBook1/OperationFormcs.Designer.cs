﻿namespace PhoneBook1
{
    partial class OperationFormcs
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.действиеBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.phonebook_LabDataSet = new PhoneBook1.Phonebook_LabDataSet();
            this.действиеTableAdapter = new PhoneBook1.Phonebook_LabDataSetTableAdapters.ДействиеTableAdapter();
            this.tableAdapterManager = new PhoneBook1.Phonebook_LabDataSetTableAdapters.TableAdapterManager();
            this.действиеDataGridView = new System.Windows.Forms.DataGridView();
            this.iDПерсоналDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.iDПользовательDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.iDКонтактDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.операцияDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.датаDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.времяDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.iDДействиеDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn7 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn4 = new System.Windows.Forms.DataGridViewComboBoxColumn();
            this.dataGridViewTextBoxColumn5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn6 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            ((System.ComponentModel.ISupportInitialize)(this.действиеBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.phonebook_LabDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.действиеDataGridView)).BeginInit();
            this.SuspendLayout();
            // 
            // действиеBindingSource
            // 
            this.действиеBindingSource.DataMember = "Действие";
            this.действиеBindingSource.DataSource = this.phonebook_LabDataSet;
            // 
            // phonebook_LabDataSet
            // 
            this.phonebook_LabDataSet.DataSetName = "Phonebook_LabDataSet";
            this.phonebook_LabDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // действиеTableAdapter
            // 
            this.действиеTableAdapter.ClearBeforeFill = true;
            // 
            // tableAdapterManager
            // 
            this.tableAdapterManager.BackupDataSetBeforeUpdate = false;
            this.tableAdapterManager.UpdateOrder = PhoneBook1.Phonebook_LabDataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete;
            this.tableAdapterManager.ДействиеTableAdapter = this.действиеTableAdapter;
            this.tableAdapterManager.КонтактTableAdapter = null;
            this.tableAdapterManager.ПерсоналTableAdapter = null;
            this.tableAdapterManager.ПользовательTableAdapter = null;
            // 
            // действиеDataGridView
            // 
            this.действиеDataGridView.AutoGenerateColumns = false;
            this.действиеDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.действиеDataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn7,
            this.dataGridViewTextBoxColumn1,
            this.dataGridViewTextBoxColumn2,
            this.dataGridViewTextBoxColumn3,
            this.dataGridViewTextBoxColumn4,
            this.dataGridViewTextBoxColumn5,
            this.dataGridViewTextBoxColumn6});
            this.действиеDataGridView.DataSource = this.действиеBindingSource;
            this.действиеDataGridView.Location = new System.Drawing.Point(1, 1);
            this.действиеDataGridView.Name = "действиеDataGridView";
            this.действиеDataGridView.RowHeadersWidth = 51;
            this.действиеDataGridView.RowTemplate.Height = 24;
            this.действиеDataGridView.Size = new System.Drawing.Size(994, 550);
            this.действиеDataGridView.TabIndex = 0;
            this.действиеDataGridView.CellFormatting += new System.Windows.Forms.DataGridViewCellFormattingEventHandler(this.действиеDataGridView_CellFormatting);
            // 
            // iDПерсоналDataGridViewTextBoxColumn
            // 
            this.iDПерсоналDataGridViewTextBoxColumn.DataPropertyName = "ID_Персонал";
            this.iDПерсоналDataGridViewTextBoxColumn.HeaderText = "ID_Персонал";
            this.iDПерсоналDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.iDПерсоналDataGridViewTextBoxColumn.Name = "iDПерсоналDataGridViewTextBoxColumn";
            this.iDПерсоналDataGridViewTextBoxColumn.Width = 125;
            // 
            // iDПользовательDataGridViewTextBoxColumn
            // 
            this.iDПользовательDataGridViewTextBoxColumn.DataPropertyName = "ID_Пользователь";
            this.iDПользовательDataGridViewTextBoxColumn.HeaderText = "ID_Пользователь";
            this.iDПользовательDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.iDПользовательDataGridViewTextBoxColumn.Name = "iDПользовательDataGridViewTextBoxColumn";
            this.iDПользовательDataGridViewTextBoxColumn.Width = 125;
            // 
            // iDКонтактDataGridViewTextBoxColumn
            // 
            this.iDКонтактDataGridViewTextBoxColumn.DataPropertyName = "ID_Контакт";
            this.iDКонтактDataGridViewTextBoxColumn.HeaderText = "ID_Контакт";
            this.iDКонтактDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.iDКонтактDataGridViewTextBoxColumn.Name = "iDКонтактDataGridViewTextBoxColumn";
            this.iDКонтактDataGridViewTextBoxColumn.Width = 125;
            // 
            // операцияDataGridViewTextBoxColumn
            // 
            this.операцияDataGridViewTextBoxColumn.DataPropertyName = "Операция";
            this.операцияDataGridViewTextBoxColumn.HeaderText = "Операция";
            this.операцияDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.операцияDataGridViewTextBoxColumn.Name = "операцияDataGridViewTextBoxColumn";
            this.операцияDataGridViewTextBoxColumn.Width = 125;
            // 
            // датаDataGridViewTextBoxColumn
            // 
            this.датаDataGridViewTextBoxColumn.DataPropertyName = "Дата";
            this.датаDataGridViewTextBoxColumn.HeaderText = "Дата";
            this.датаDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.датаDataGridViewTextBoxColumn.Name = "датаDataGridViewTextBoxColumn";
            this.датаDataGridViewTextBoxColumn.Width = 125;
            // 
            // времяDataGridViewTextBoxColumn
            // 
            this.времяDataGridViewTextBoxColumn.DataPropertyName = "Время";
            this.времяDataGridViewTextBoxColumn.HeaderText = "Время";
            this.времяDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.времяDataGridViewTextBoxColumn.Name = "времяDataGridViewTextBoxColumn";
            this.времяDataGridViewTextBoxColumn.Width = 125;
            // 
            // iDДействиеDataGridViewTextBoxColumn
            // 
            this.iDДействиеDataGridViewTextBoxColumn.DataPropertyName = "ID_Действие";
            this.iDДействиеDataGridViewTextBoxColumn.HeaderText = "ID_Действие";
            this.iDДействиеDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.iDДействиеDataGridViewTextBoxColumn.Name = "iDДействиеDataGridViewTextBoxColumn";
            this.iDДействиеDataGridViewTextBoxColumn.ReadOnly = true;
            this.iDДействиеDataGridViewTextBoxColumn.Width = 125;
            // 
            // dataGridViewTextBoxColumn7
            // 
            this.dataGridViewTextBoxColumn7.DataPropertyName = "ID_Действие";
            this.dataGridViewTextBoxColumn7.HeaderText = "ID_Действие";
            this.dataGridViewTextBoxColumn7.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn7.Name = "dataGridViewTextBoxColumn7";
            this.dataGridViewTextBoxColumn7.ReadOnly = true;
            this.dataGridViewTextBoxColumn7.Width = 125;
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.DataPropertyName = "ID_Персонал";
            this.dataGridViewTextBoxColumn1.HeaderText = "ID_Персонал";
            this.dataGridViewTextBoxColumn1.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            this.dataGridViewTextBoxColumn1.Width = 125;
            // 
            // dataGridViewTextBoxColumn2
            // 
            this.dataGridViewTextBoxColumn2.DataPropertyName = "ID_Пользователь";
            this.dataGridViewTextBoxColumn2.HeaderText = "ID_Пользователь";
            this.dataGridViewTextBoxColumn2.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            this.dataGridViewTextBoxColumn2.Width = 125;
            // 
            // dataGridViewTextBoxColumn3
            // 
            this.dataGridViewTextBoxColumn3.DataPropertyName = "ID_Контакт";
            this.dataGridViewTextBoxColumn3.HeaderText = "ID_Контакт";
            this.dataGridViewTextBoxColumn3.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn3.Name = "dataGridViewTextBoxColumn3";
            this.dataGridViewTextBoxColumn3.Width = 125;
            // 
            // dataGridViewTextBoxColumn4
            // 
            this.dataGridViewTextBoxColumn4.DataPropertyName = "Операция";
            this.dataGridViewTextBoxColumn4.HeaderText = "Операция";
            this.dataGridViewTextBoxColumn4.Items.AddRange(new object[] {
            "Read",
            "Add",
            "Modify",
            "Delete"});
            this.dataGridViewTextBoxColumn4.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn4.Name = "dataGridViewTextBoxColumn4";
            this.dataGridViewTextBoxColumn4.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridViewTextBoxColumn4.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.dataGridViewTextBoxColumn4.Width = 125;
            // 
            // dataGridViewTextBoxColumn5
            // 
            this.dataGridViewTextBoxColumn5.DataPropertyName = "Дата";
            this.dataGridViewTextBoxColumn5.HeaderText = "Дата";
            this.dataGridViewTextBoxColumn5.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn5.Name = "dataGridViewTextBoxColumn5";
            this.dataGridViewTextBoxColumn5.Width = 125;
            // 
            // dataGridViewTextBoxColumn6
            // 
            this.dataGridViewTextBoxColumn6.DataPropertyName = "Время";
            this.dataGridViewTextBoxColumn6.HeaderText = "Время";
            this.dataGridViewTextBoxColumn6.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn6.Name = "dataGridViewTextBoxColumn6";
            this.dataGridViewTextBoxColumn6.Width = 125;
            // 
            // OperationFormcs
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(995, 556);
            this.Controls.Add(this.действиеDataGridView);
            this.Name = "OperationFormcs";
            this.Text = "История действии";
            this.Load += new System.EventHandler(this.OperationFormcs_Load);
            ((System.ComponentModel.ISupportInitialize)(this.действиеBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.phonebook_LabDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.действиеDataGridView)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private Phonebook_LabDataSet phonebook_LabDataSet;
        private System.Windows.Forms.BindingSource действиеBindingSource;
        private Phonebook_LabDataSetTableAdapters.ДействиеTableAdapter действиеTableAdapter;
        private Phonebook_LabDataSetTableAdapters.TableAdapterManager tableAdapterManager;
        private System.Windows.Forms.DataGridView действиеDataGridView;
        private System.Windows.Forms.DataGridViewTextBoxColumn iDПерсоналDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn iDПользовательDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn iDКонтактDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn операцияDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn датаDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn времяDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn iDДействиеDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn7;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn3;
        private System.Windows.Forms.DataGridViewComboBoxColumn dataGridViewTextBoxColumn4;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn5;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn6;
    }
}