﻿namespace PhoneBook1
{
    partial class ConctactForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.Label iD_КонтактLabel;
            System.Windows.Forms.Label iD_ПользLabel;
            System.Windows.Forms.Label iD_ПерсоLabel;
            System.Windows.Forms.Label дата_измененияLabel;
            System.Windows.Forms.Label время_измененияLabel;
            System.Windows.Forms.Label блокированLabel;
            System.Windows.Forms.Label персоналLabel;
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ConctactForm));
            this.контактBindingNavigator = new System.Windows.Forms.BindingNavigator(this.components);
            this.bindingNavigatorAddNewItem = new System.Windows.Forms.ToolStripButton();
            this.контактBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.phonebook_LabDataSet = new PhoneBook1.Phonebook_LabDataSet();
            this.bindingNavigatorCountItem = new System.Windows.Forms.ToolStripLabel();
            this.bindingNavigatorDeleteItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMoveFirstItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMovePreviousItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorPositionItem = new System.Windows.Forms.ToolStripTextBox();
            this.bindingNavigatorSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorMoveNextItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMoveLastItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.контактBindingNavigatorSaveItem = new System.Windows.Forms.ToolStripButton();
            this.iD_КонтактTextBox = new System.Windows.Forms.TextBox();
            this.iD_ПользTextBox = new System.Windows.Forms.TextBox();
            this.iD_ПерсоTextBox = new System.Windows.Forms.TextBox();
            this.дата_измененияDateTimePicker = new System.Windows.Forms.DateTimePicker();
            this.время_измененияTextBox = new System.Windows.Forms.TextBox();
            this.блокированCheckBox = new System.Windows.Forms.CheckBox();
            this.OperationContentGroupBox = new System.Windows.Forms.GroupBox();
            this.историяNavigator = new System.Windows.Forms.BindingNavigator(this.components);
            this.toolStripButton1 = new System.Windows.Forms.ToolStripButton();
            this.действиеBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.toolStripLabel1 = new System.Windows.Forms.ToolStripLabel();
            this.toolStripButton2 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton3 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton4 = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripTextBox1 = new System.Windows.Forms.ToolStripTextBox();
            this.toolStripSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripButton5 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton6 = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator3 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripButton7 = new System.Windows.Forms.ToolStripButton();
            this.действиеDataGridView = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewButtonColumn();
            this.dataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn4 = new System.Windows.Forms.DataGridViewComboBoxColumn();
            this.dataGridViewTextBoxColumn5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn6 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn7 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.персоналBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.контактTableAdapter = new PhoneBook1.Phonebook_LabDataSetTableAdapters.КонтактTableAdapter();
            this.tableAdapterManager = new PhoneBook1.Phonebook_LabDataSetTableAdapters.TableAdapterManager();
            this.действиеTableAdapter = new PhoneBook1.Phonebook_LabDataSetTableAdapters.ДействиеTableAdapter();
            this.персоналTableAdapter = new PhoneBook1.Phonebook_LabDataSetTableAdapters.ПерсоналTableAdapter();
            this.персоналLabel1 = new System.Windows.Forms.Label();
            this.buttonWorker = new System.Windows.Forms.Button();
            iD_КонтактLabel = new System.Windows.Forms.Label();
            iD_ПользLabel = new System.Windows.Forms.Label();
            iD_ПерсоLabel = new System.Windows.Forms.Label();
            дата_измененияLabel = new System.Windows.Forms.Label();
            время_измененияLabel = new System.Windows.Forms.Label();
            блокированLabel = new System.Windows.Forms.Label();
            персоналLabel = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.контактBindingNavigator)).BeginInit();
            this.контактBindingNavigator.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.контактBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.phonebook_LabDataSet)).BeginInit();
            this.OperationContentGroupBox.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.историяNavigator)).BeginInit();
            this.историяNavigator.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.действиеBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.действиеDataGridView)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.персоналBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // iD_КонтактLabel
            // 
            iD_КонтактLabel.AutoSize = true;
            iD_КонтактLabel.Location = new System.Drawing.Point(15, 38);
            iD_КонтактLabel.Name = "iD_КонтактLabel";
            iD_КонтактLabel.Size = new System.Drawing.Size(79, 16);
            iD_КонтактLabel.TabIndex = 1;
            iD_КонтактLabel.Text = "ID Контакт:";
            // 
            // iD_ПользLabel
            // 
            iD_ПользLabel.AutoSize = true;
            iD_ПользLabel.Location = new System.Drawing.Point(15, 66);
            iD_ПользLabel.Name = "iD_ПользLabel";
            iD_ПользLabel.Size = new System.Drawing.Size(67, 16);
            iD_ПользLabel.TabIndex = 3;
            iD_ПользLabel.Text = "ID Польз:";
            // 
            // iD_ПерсоLabel
            // 
            iD_ПерсоLabel.AutoSize = true;
            iD_ПерсоLabel.Location = new System.Drawing.Point(15, 94);
            iD_ПерсоLabel.Name = "iD_ПерсоLabel";
            iD_ПерсоLabel.Size = new System.Drawing.Size(67, 16);
            iD_ПерсоLabel.TabIndex = 5;
            iD_ПерсоLabel.Text = "ID Персо:";
            // 
            // дата_измененияLabel
            // 
            дата_измененияLabel.AutoSize = true;
            дата_измененияLabel.Location = new System.Drawing.Point(15, 150);
            дата_измененияLabel.Name = "дата_измененияLabel";
            дата_измененияLabel.Size = new System.Drawing.Size(117, 16);
            дата_измененияLabel.TabIndex = 7;
            дата_измененияLabel.Text = "Дата изменения:";
            // 
            // время_измененияLabel
            // 
            время_измененияLabel.AutoSize = true;
            время_измененияLabel.Location = new System.Drawing.Point(15, 177);
            время_измененияLabel.Name = "время_измененияLabel";
            время_измененияLabel.Size = new System.Drawing.Size(126, 16);
            время_измененияLabel.TabIndex = 9;
            время_измененияLabel.Text = "Время изменения:";
            // 
            // блокированLabel
            // 
            блокированLabel.AutoSize = true;
            блокированLabel.Location = new System.Drawing.Point(15, 207);
            блокированLabel.Name = "блокированLabel";
            блокированLabel.Size = new System.Drawing.Size(90, 16);
            блокированLabel.TabIndex = 11;
            блокированLabel.Text = "Блокирован:";
            // 
            // персоналLabel
            // 
            персоналLabel.AutoSize = true;
            персоналLabel.Location = new System.Drawing.Point(15, 122);
            персоналLabel.Name = "персоналLabel";
            персоналLabel.Size = new System.Drawing.Size(75, 16);
            персоналLabel.TabIndex = 17;
            персоналLabel.Text = "Персонал:";
            // 
            // контактBindingNavigator
            // 
            this.контактBindingNavigator.AddNewItem = this.bindingNavigatorAddNewItem;
            this.контактBindingNavigator.BindingSource = this.контактBindingSource;
            this.контактBindingNavigator.CountItem = this.bindingNavigatorCountItem;
            this.контактBindingNavigator.DeleteItem = this.bindingNavigatorDeleteItem;
            this.контактBindingNavigator.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.контактBindingNavigator.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.bindingNavigatorMoveFirstItem,
            this.bindingNavigatorMovePreviousItem,
            this.bindingNavigatorSeparator,
            this.bindingNavigatorPositionItem,
            this.bindingNavigatorCountItem,
            this.bindingNavigatorSeparator1,
            this.bindingNavigatorMoveNextItem,
            this.bindingNavigatorMoveLastItem,
            this.bindingNavigatorSeparator2,
            this.bindingNavigatorAddNewItem,
            this.bindingNavigatorDeleteItem,
            this.контактBindingNavigatorSaveItem});
            this.контактBindingNavigator.Location = new System.Drawing.Point(0, 0);
            this.контактBindingNavigator.MoveFirstItem = this.bindingNavigatorMoveFirstItem;
            this.контактBindingNavigator.MoveLastItem = this.bindingNavigatorMoveLastItem;
            this.контактBindingNavigator.MoveNextItem = this.bindingNavigatorMoveNextItem;
            this.контактBindingNavigator.MovePreviousItem = this.bindingNavigatorMovePreviousItem;
            this.контактBindingNavigator.Name = "контактBindingNavigator";
            this.контактBindingNavigator.PositionItem = this.bindingNavigatorPositionItem;
            this.контактBindingNavigator.Size = new System.Drawing.Size(1035, 31);
            this.контактBindingNavigator.TabIndex = 0;
            this.контактBindingNavigator.Text = "bindingNavigator1";
            // 
            // bindingNavigatorAddNewItem
            // 
            this.bindingNavigatorAddNewItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorAddNewItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorAddNewItem.Image")));
            this.bindingNavigatorAddNewItem.Name = "bindingNavigatorAddNewItem";
            this.bindingNavigatorAddNewItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorAddNewItem.Size = new System.Drawing.Size(29, 28);
            this.bindingNavigatorAddNewItem.Text = "Add new";
            // 
            // контактBindingSource
            // 
            this.контактBindingSource.DataMember = "Контакт";
            this.контактBindingSource.DataSource = this.phonebook_LabDataSet;
            // 
            // phonebook_LabDataSet
            // 
            this.phonebook_LabDataSet.DataSetName = "Phonebook_LabDataSet";
            this.phonebook_LabDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // bindingNavigatorCountItem
            // 
            this.bindingNavigatorCountItem.Name = "bindingNavigatorCountItem";
            this.bindingNavigatorCountItem.Size = new System.Drawing.Size(45, 24);
            this.bindingNavigatorCountItem.Text = "of {0}";
            this.bindingNavigatorCountItem.ToolTipText = "Total number of items";
            // 
            // bindingNavigatorDeleteItem
            // 
            this.bindingNavigatorDeleteItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorDeleteItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorDeleteItem.Image")));
            this.bindingNavigatorDeleteItem.Name = "bindingNavigatorDeleteItem";
            this.bindingNavigatorDeleteItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorDeleteItem.Size = new System.Drawing.Size(29, 24);
            this.bindingNavigatorDeleteItem.Text = "Delete";
            // 
            // bindingNavigatorMoveFirstItem
            // 
            this.bindingNavigatorMoveFirstItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveFirstItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveFirstItem.Image")));
            this.bindingNavigatorMoveFirstItem.Name = "bindingNavigatorMoveFirstItem";
            this.bindingNavigatorMoveFirstItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveFirstItem.Size = new System.Drawing.Size(29, 24);
            this.bindingNavigatorMoveFirstItem.Text = "Move first";
            // 
            // bindingNavigatorMovePreviousItem
            // 
            this.bindingNavigatorMovePreviousItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMovePreviousItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMovePreviousItem.Image")));
            this.bindingNavigatorMovePreviousItem.Name = "bindingNavigatorMovePreviousItem";
            this.bindingNavigatorMovePreviousItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMovePreviousItem.Size = new System.Drawing.Size(29, 24);
            this.bindingNavigatorMovePreviousItem.Text = "Move previous";
            // 
            // bindingNavigatorSeparator
            // 
            this.bindingNavigatorSeparator.Name = "bindingNavigatorSeparator";
            this.bindingNavigatorSeparator.Size = new System.Drawing.Size(6, 27);
            // 
            // bindingNavigatorPositionItem
            // 
            this.bindingNavigatorPositionItem.AccessibleName = "Position";
            this.bindingNavigatorPositionItem.AutoSize = false;
            this.bindingNavigatorPositionItem.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.bindingNavigatorPositionItem.Name = "bindingNavigatorPositionItem";
            this.bindingNavigatorPositionItem.Size = new System.Drawing.Size(50, 27);
            this.bindingNavigatorPositionItem.Text = "0";
            this.bindingNavigatorPositionItem.ToolTipText = "Current position";
            // 
            // bindingNavigatorSeparator1
            // 
            this.bindingNavigatorSeparator1.Name = "bindingNavigatorSeparator1";
            this.bindingNavigatorSeparator1.Size = new System.Drawing.Size(6, 27);
            // 
            // bindingNavigatorMoveNextItem
            // 
            this.bindingNavigatorMoveNextItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveNextItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveNextItem.Image")));
            this.bindingNavigatorMoveNextItem.Name = "bindingNavigatorMoveNextItem";
            this.bindingNavigatorMoveNextItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveNextItem.Size = new System.Drawing.Size(29, 24);
            this.bindingNavigatorMoveNextItem.Text = "Move next";
            // 
            // bindingNavigatorMoveLastItem
            // 
            this.bindingNavigatorMoveLastItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveLastItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveLastItem.Image")));
            this.bindingNavigatorMoveLastItem.Name = "bindingNavigatorMoveLastItem";
            this.bindingNavigatorMoveLastItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveLastItem.Size = new System.Drawing.Size(29, 24);
            this.bindingNavigatorMoveLastItem.Text = "Move last";
            // 
            // bindingNavigatorSeparator2
            // 
            this.bindingNavigatorSeparator2.Name = "bindingNavigatorSeparator2";
            this.bindingNavigatorSeparator2.Size = new System.Drawing.Size(6, 27);
            // 
            // контактBindingNavigatorSaveItem
            // 
            this.контактBindingNavigatorSaveItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.контактBindingNavigatorSaveItem.Image = ((System.Drawing.Image)(resources.GetObject("контактBindingNavigatorSaveItem.Image")));
            this.контактBindingNavigatorSaveItem.Name = "контактBindingNavigatorSaveItem";
            this.контактBindingNavigatorSaveItem.Size = new System.Drawing.Size(29, 24);
            this.контактBindingNavigatorSaveItem.Text = "Save Data";
            this.контактBindingNavigatorSaveItem.Click += new System.EventHandler(this.контактBindingNavigatorSaveItem_Click);
            // 
            // iD_КонтактTextBox
            // 
            this.iD_КонтактTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.контактBindingSource, "ID_Контакт", true));
            this.iD_КонтактTextBox.Location = new System.Drawing.Point(147, 35);
            this.iD_КонтактTextBox.Name = "iD_КонтактTextBox";
            this.iD_КонтактTextBox.Size = new System.Drawing.Size(200, 22);
            this.iD_КонтактTextBox.TabIndex = 2;
            // 
            // iD_ПользTextBox
            // 
            this.iD_ПользTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.контактBindingSource, "ID_Польз", true));
            this.iD_ПользTextBox.Location = new System.Drawing.Point(147, 63);
            this.iD_ПользTextBox.Name = "iD_ПользTextBox";
            this.iD_ПользTextBox.Size = new System.Drawing.Size(200, 22);
            this.iD_ПользTextBox.TabIndex = 4;
            // 
            // iD_ПерсоTextBox
            // 
            this.iD_ПерсоTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.контактBindingSource, "ID_Персо", true));
            this.iD_ПерсоTextBox.Location = new System.Drawing.Point(147, 91);
            this.iD_ПерсоTextBox.Name = "iD_ПерсоTextBox";
            this.iD_ПерсоTextBox.Size = new System.Drawing.Size(200, 22);
            this.iD_ПерсоTextBox.TabIndex = 6;
            // 
            // дата_измененияDateTimePicker
            // 
            this.дата_измененияDateTimePicker.DataBindings.Add(new System.Windows.Forms.Binding("Value", this.контактBindingSource, "Дата_изменения", true));
            this.дата_измененияDateTimePicker.Location = new System.Drawing.Point(147, 146);
            this.дата_измененияDateTimePicker.Name = "дата_измененияDateTimePicker";
            this.дата_измененияDateTimePicker.Size = new System.Drawing.Size(200, 22);
            this.дата_измененияDateTimePicker.TabIndex = 8;
            // 
            // время_измененияTextBox
            // 
            this.время_измененияTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.контактBindingSource, "Время_изменения", true));
            this.время_измененияTextBox.Location = new System.Drawing.Point(147, 174);
            this.время_измененияTextBox.Name = "время_измененияTextBox";
            this.время_измененияTextBox.Size = new System.Drawing.Size(200, 22);
            this.время_измененияTextBox.TabIndex = 10;
            // 
            // блокированCheckBox
            // 
            this.блокированCheckBox.DataBindings.Add(new System.Windows.Forms.Binding("CheckState", this.контактBindingSource, "Блокирован", true));
            this.блокированCheckBox.Location = new System.Drawing.Point(147, 202);
            this.блокированCheckBox.Name = "блокированCheckBox";
            this.блокированCheckBox.Size = new System.Drawing.Size(200, 24);
            this.блокированCheckBox.TabIndex = 12;
            this.блокированCheckBox.UseVisualStyleBackColor = true;
            // 
            // OperationContentGroupBox
            // 
            this.OperationContentGroupBox.Controls.Add(this.историяNavigator);
            this.OperationContentGroupBox.Controls.Add(this.действиеDataGridView);
            this.OperationContentGroupBox.Location = new System.Drawing.Point(15, 241);
            this.OperationContentGroupBox.Name = "OperationContentGroupBox";
            this.OperationContentGroupBox.Size = new System.Drawing.Size(1000, 314);
            this.OperationContentGroupBox.TabIndex = 13;
            this.OperationContentGroupBox.TabStop = false;
            this.OperationContentGroupBox.Text = "История действии";
            // 
            // историяNavigator
            // 
            this.историяNavigator.AddNewItem = this.toolStripButton1;
            this.историяNavigator.BindingSource = this.действиеBindingSource;
            this.историяNavigator.CountItem = this.toolStripLabel1;
            this.историяNavigator.DeleteItem = this.toolStripButton2;
            this.историяNavigator.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.историяNavigator.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripButton3,
            this.toolStripButton4,
            this.toolStripSeparator1,
            this.toolStripTextBox1,
            this.toolStripLabel1,
            this.toolStripSeparator2,
            this.toolStripButton5,
            this.toolStripButton6,
            this.toolStripSeparator3,
            this.toolStripButton1,
            this.toolStripButton2,
            this.toolStripButton7});
            this.историяNavigator.Location = new System.Drawing.Point(3, 18);
            this.историяNavigator.MoveFirstItem = this.toolStripButton3;
            this.историяNavigator.MoveLastItem = this.toolStripButton6;
            this.историяNavigator.MoveNextItem = this.toolStripButton5;
            this.историяNavigator.MovePreviousItem = this.toolStripButton4;
            this.историяNavigator.Name = "историяNavigator";
            this.историяNavigator.PositionItem = this.toolStripTextBox1;
            this.историяNavigator.Size = new System.Drawing.Size(994, 31);
            this.историяNavigator.TabIndex = 1;
            this.историяNavigator.Text = "историяNavigator";
            // 
            // toolStripButton1
            // 
            this.toolStripButton1.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton1.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton1.Image")));
            this.toolStripButton1.Name = "toolStripButton1";
            this.toolStripButton1.RightToLeftAutoMirrorImage = true;
            this.toolStripButton1.Size = new System.Drawing.Size(29, 24);
            this.toolStripButton1.Text = "Add new";
            // 
            // действиеBindingSource
            // 
            this.действиеBindingSource.DataMember = "FK_Действие_Контакт";
            this.действиеBindingSource.DataSource = this.контактBindingSource;
            // 
            // toolStripLabel1
            // 
            this.toolStripLabel1.Name = "toolStripLabel1";
            this.toolStripLabel1.Size = new System.Drawing.Size(45, 24);
            this.toolStripLabel1.Text = "of {0}";
            this.toolStripLabel1.ToolTipText = "Total number of items";
            // 
            // toolStripButton2
            // 
            this.toolStripButton2.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton2.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton2.Image")));
            this.toolStripButton2.Name = "toolStripButton2";
            this.toolStripButton2.RightToLeftAutoMirrorImage = true;
            this.toolStripButton2.Size = new System.Drawing.Size(29, 24);
            this.toolStripButton2.Text = "Delete";
            // 
            // toolStripButton3
            // 
            this.toolStripButton3.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton3.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton3.Image")));
            this.toolStripButton3.Name = "toolStripButton3";
            this.toolStripButton3.RightToLeftAutoMirrorImage = true;
            this.toolStripButton3.Size = new System.Drawing.Size(29, 24);
            this.toolStripButton3.Text = "Move first";
            // 
            // toolStripButton4
            // 
            this.toolStripButton4.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton4.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton4.Image")));
            this.toolStripButton4.Name = "toolStripButton4";
            this.toolStripButton4.RightToLeftAutoMirrorImage = true;
            this.toolStripButton4.Size = new System.Drawing.Size(29, 24);
            this.toolStripButton4.Text = "Move previous";
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(6, 27);
            // 
            // toolStripTextBox1
            // 
            this.toolStripTextBox1.AccessibleName = "Position";
            this.toolStripTextBox1.AutoSize = false;
            this.toolStripTextBox1.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.toolStripTextBox1.Name = "toolStripTextBox1";
            this.toolStripTextBox1.Size = new System.Drawing.Size(50, 27);
            this.toolStripTextBox1.Text = "0";
            this.toolStripTextBox1.ToolTipText = "Current position";
            // 
            // toolStripSeparator2
            // 
            this.toolStripSeparator2.Name = "toolStripSeparator2";
            this.toolStripSeparator2.Size = new System.Drawing.Size(6, 27);
            // 
            // toolStripButton5
            // 
            this.toolStripButton5.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton5.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton5.Image")));
            this.toolStripButton5.Name = "toolStripButton5";
            this.toolStripButton5.RightToLeftAutoMirrorImage = true;
            this.toolStripButton5.Size = new System.Drawing.Size(29, 24);
            this.toolStripButton5.Text = "Move next";
            // 
            // toolStripButton6
            // 
            this.toolStripButton6.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton6.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton6.Image")));
            this.toolStripButton6.Name = "toolStripButton6";
            this.toolStripButton6.RightToLeftAutoMirrorImage = true;
            this.toolStripButton6.Size = new System.Drawing.Size(29, 24);
            this.toolStripButton6.Text = "Move last";
            // 
            // toolStripSeparator3
            // 
            this.toolStripSeparator3.Name = "toolStripSeparator3";
            this.toolStripSeparator3.Size = new System.Drawing.Size(6, 27);
            // 
            // toolStripButton7
            // 
            this.toolStripButton7.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton7.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton7.Image")));
            this.toolStripButton7.Name = "toolStripButton7";
            this.toolStripButton7.Size = new System.Drawing.Size(29, 24);
            this.toolStripButton7.Text = "Save Data";
            this.toolStripButton7.Click += new System.EventHandler(this.toolStripButton7_Click);
            // 
            // действиеDataGridView
            // 
            this.действиеDataGridView.AutoGenerateColumns = false;
            this.действиеDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.действиеDataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn1,
            this.dataGridViewTextBoxColumn2,
            this.dataGridViewTextBoxColumn3,
            this.dataGridViewTextBoxColumn4,
            this.dataGridViewTextBoxColumn5,
            this.dataGridViewTextBoxColumn6,
            this.dataGridViewTextBoxColumn7});
            this.действиеDataGridView.DataSource = this.действиеBindingSource;
            this.действиеDataGridView.Location = new System.Drawing.Point(6, 52);
            this.действиеDataGridView.Name = "действиеDataGridView";
            this.действиеDataGridView.RowHeadersWidth = 51;
            this.действиеDataGridView.RowTemplate.Height = 24;
            this.действиеDataGridView.Size = new System.Drawing.Size(988, 274);
            this.действиеDataGridView.TabIndex = 0;
            this.действиеDataGridView.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.действиеDataGridView_CellClick);
            this.действиеDataGridView.CellFormatting += new System.Windows.Forms.DataGridViewCellFormattingEventHandler(this.действиеDataGridView_CellFormatting);
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.DataPropertyName = "ID_Персонал";
            this.dataGridViewTextBoxColumn1.HeaderText = "ID_Персонал";
            this.dataGridViewTextBoxColumn1.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            this.dataGridViewTextBoxColumn1.Width = 125;
            // 
            // dataGridViewTextBoxColumn2
            // 
            this.dataGridViewTextBoxColumn2.DataPropertyName = "ID_Пользователь";
            this.dataGridViewTextBoxColumn2.HeaderText = "ID_Пользователь";
            this.dataGridViewTextBoxColumn2.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            this.dataGridViewTextBoxColumn2.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridViewTextBoxColumn2.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.dataGridViewTextBoxColumn2.Width = 125;
            // 
            // dataGridViewTextBoxColumn3
            // 
            this.dataGridViewTextBoxColumn3.DataPropertyName = "ID_Контакт";
            this.dataGridViewTextBoxColumn3.HeaderText = "ID_Контакт";
            this.dataGridViewTextBoxColumn3.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn3.Name = "dataGridViewTextBoxColumn3";
            this.dataGridViewTextBoxColumn3.Width = 125;
            // 
            // dataGridViewTextBoxColumn4
            // 
            this.dataGridViewTextBoxColumn4.DataPropertyName = "Операция";
            this.dataGridViewTextBoxColumn4.HeaderText = "Операция";
            this.dataGridViewTextBoxColumn4.Items.AddRange(new object[] {
            "Read",
            "Add",
            "Modify",
            "Delete"});
            this.dataGridViewTextBoxColumn4.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn4.Name = "dataGridViewTextBoxColumn4";
            this.dataGridViewTextBoxColumn4.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridViewTextBoxColumn4.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.dataGridViewTextBoxColumn4.Width = 125;
            // 
            // dataGridViewTextBoxColumn5
            // 
            this.dataGridViewTextBoxColumn5.DataPropertyName = "Дата";
            this.dataGridViewTextBoxColumn5.HeaderText = "Дата";
            this.dataGridViewTextBoxColumn5.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn5.Name = "dataGridViewTextBoxColumn5";
            this.dataGridViewTextBoxColumn5.Width = 125;
            // 
            // dataGridViewTextBoxColumn6
            // 
            this.dataGridViewTextBoxColumn6.DataPropertyName = "Время";
            this.dataGridViewTextBoxColumn6.HeaderText = "Время";
            this.dataGridViewTextBoxColumn6.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn6.Name = "dataGridViewTextBoxColumn6";
            this.dataGridViewTextBoxColumn6.Width = 125;
            // 
            // dataGridViewTextBoxColumn7
            // 
            this.dataGridViewTextBoxColumn7.DataPropertyName = "ID_Действие";
            this.dataGridViewTextBoxColumn7.HeaderText = "ID_Действие";
            this.dataGridViewTextBoxColumn7.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn7.Name = "dataGridViewTextBoxColumn7";
            this.dataGridViewTextBoxColumn7.ReadOnly = true;
            this.dataGridViewTextBoxColumn7.Width = 125;
            // 
            // персоналBindingSource
            // 
            this.персоналBindingSource.DataMember = "Персонал";
            this.персоналBindingSource.DataSource = this.phonebook_LabDataSet;
            // 
            // контактTableAdapter
            // 
            this.контактTableAdapter.ClearBeforeFill = true;
            // 
            // tableAdapterManager
            // 
            this.tableAdapterManager.BackupDataSetBeforeUpdate = false;
            this.tableAdapterManager.UpdateOrder = PhoneBook1.Phonebook_LabDataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete;
            this.tableAdapterManager.ДействиеTableAdapter = this.действиеTableAdapter;
            this.tableAdapterManager.КонтактTableAdapter = this.контактTableAdapter;
            this.tableAdapterManager.ПерсоналTableAdapter = null;
            this.tableAdapterManager.ПользовательTableAdapter = null;
            // 
            // действиеTableAdapter
            // 
            this.действиеTableAdapter.ClearBeforeFill = true;
            // 
            // персоналTableAdapter
            // 
            this.персоналTableAdapter.ClearBeforeFill = true;
            // 
            // персоналLabel1
            // 
            this.персоналLabel1.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.контактBindingSource, "Персонал", true));
            this.персоналLabel1.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.персоналLabel1.ForeColor = System.Drawing.SystemColors.MenuHighlight;
            this.персоналLabel1.Location = new System.Drawing.Point(144, 122);
            this.персоналLabel1.Name = "персоналLabel1";
            this.персоналLabel1.Size = new System.Drawing.Size(686, 23);
            this.персоналLabel1.TabIndex = 18;
            this.персоналLabel1.Text = "label1";
            // 
            // buttonWorker
            // 
            this.buttonWorker.Image = global::PhoneBook1.Properties.Resources.travailleur_du_centre_dappels_avec_casque__1_;
            this.buttonWorker.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.buttonWorker.Location = new System.Drawing.Point(389, 156);
            this.buttonWorker.Name = "buttonWorker";
            this.buttonWorker.Size = new System.Drawing.Size(135, 40);
            this.buttonWorker.TabIndex = 14;
            this.buttonWorker.Text = "Персонал";
            this.buttonWorker.UseVisualStyleBackColor = true;
            this.buttonWorker.Click += new System.EventHandler(this.button1_Click);
            // 
            // ConctactForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1035, 575);
            this.Controls.Add(персоналLabel);
            this.Controls.Add(this.персоналLabel1);
            this.Controls.Add(this.buttonWorker);
            this.Controls.Add(this.OperationContentGroupBox);
            this.Controls.Add(iD_КонтактLabel);
            this.Controls.Add(this.iD_КонтактTextBox);
            this.Controls.Add(iD_ПользLabel);
            this.Controls.Add(this.iD_ПользTextBox);
            this.Controls.Add(iD_ПерсоLabel);
            this.Controls.Add(this.iD_ПерсоTextBox);
            this.Controls.Add(дата_измененияLabel);
            this.Controls.Add(this.дата_измененияDateTimePicker);
            this.Controls.Add(время_измененияLabel);
            this.Controls.Add(this.время_измененияTextBox);
            this.Controls.Add(блокированLabel);
            this.Controls.Add(this.блокированCheckBox);
            this.Controls.Add(this.контактBindingNavigator);
            this.Name = "ConctactForm";
            this.Text = "Списка контактов";
            this.Load += new System.EventHandler(this.ConctactForm_Load);
            this.Shown += new System.EventHandler(this.ConctactForm_Shown);
            ((System.ComponentModel.ISupportInitialize)(this.контактBindingNavigator)).EndInit();
            this.контактBindingNavigator.ResumeLayout(false);
            this.контактBindingNavigator.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.контактBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.phonebook_LabDataSet)).EndInit();
            this.OperationContentGroupBox.ResumeLayout(false);
            this.OperationContentGroupBox.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.историяNavigator)).EndInit();
            this.историяNavigator.ResumeLayout(false);
            this.историяNavigator.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.действиеBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.действиеDataGridView)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.персоналBindingSource)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Phonebook_LabDataSet phonebook_LabDataSet;
        private System.Windows.Forms.BindingSource контактBindingSource;
        private Phonebook_LabDataSetTableAdapters.КонтактTableAdapter контактTableAdapter;
        private Phonebook_LabDataSetTableAdapters.TableAdapterManager tableAdapterManager;
        private System.Windows.Forms.BindingNavigator контактBindingNavigator;
        private System.Windows.Forms.ToolStripButton bindingNavigatorAddNewItem;
        private System.Windows.Forms.ToolStripLabel bindingNavigatorCountItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorDeleteItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveFirstItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMovePreviousItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator;
        private System.Windows.Forms.ToolStripTextBox bindingNavigatorPositionItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator1;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveNextItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveLastItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator2;
        private System.Windows.Forms.ToolStripButton контактBindingNavigatorSaveItem;
        private System.Windows.Forms.TextBox iD_КонтактTextBox;
        private System.Windows.Forms.TextBox iD_ПользTextBox;
        private System.Windows.Forms.TextBox iD_ПерсоTextBox;
        private System.Windows.Forms.DateTimePicker дата_измененияDateTimePicker;
        private System.Windows.Forms.TextBox время_измененияTextBox;
        private System.Windows.Forms.CheckBox блокированCheckBox;
        private Phonebook_LabDataSetTableAdapters.ДействиеTableAdapter действиеTableAdapter;
        private System.Windows.Forms.GroupBox OperationContentGroupBox;
        private System.Windows.Forms.BindingSource действиеBindingSource;
        private System.Windows.Forms.DataGridView действиеDataGridView;
        private System.Windows.Forms.BindingNavigator историяNavigator;
        private System.Windows.Forms.ToolStripButton toolStripButton1;
        private System.Windows.Forms.ToolStripLabel toolStripLabel1;
        private System.Windows.Forms.ToolStripButton toolStripButton2;
        private System.Windows.Forms.ToolStripButton toolStripButton3;
        private System.Windows.Forms.ToolStripButton toolStripButton4;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.ToolStripTextBox toolStripTextBox1;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator2;
        private System.Windows.Forms.ToolStripButton toolStripButton5;
        private System.Windows.Forms.ToolStripButton toolStripButton6;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator3;
        private System.Windows.Forms.ToolStripButton toolStripButton7;
        private System.Windows.Forms.Button buttonWorker;
        private System.Windows.Forms.BindingSource персоналBindingSource;
        private Phonebook_LabDataSetTableAdapters.ПерсоналTableAdapter персоналTableAdapter;
        private System.Windows.Forms.Label персоналLabel1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewButtonColumn dataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn3;
        private System.Windows.Forms.DataGridViewComboBoxColumn dataGridViewTextBoxColumn4;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn5;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn6;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn7;
    }
}