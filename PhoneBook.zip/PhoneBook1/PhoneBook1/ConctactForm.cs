﻿using PhoneBook1.Phonebook_LabDataSetTableAdapters;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PhoneBook1
{
    public partial class ConctactForm : Form
    {
        public ConctactForm()
        {
            InitializeComponent();
        }

        private static ConctactForm c;
        public static ConctactForm cd
        {
            get
            {
                if (c == null || c.IsDisposed)
                {
                    c = new ConctactForm();
                }
                return c;
            }
        }

        public void ShowForm()
        {
            Show();
            Activate();
        }

        private void ConctactForm_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'phonebook_LabDataSet.Персонал' table. You can move, or remove it, as needed.
            this.персоналTableAdapter.Fill(this.phonebook_LabDataSet.Персонал);
            // TODO: This line of code loads data into the 'phonebook_LabDataSet.Действие' table. You can move, or remove it, as needed.
            this.действиеTableAdapter.Fill(this.phonebook_LabDataSet.Действие);
            // TODO: This line of code loads data into the 'phonebook_LabDataSet.Контакт' table. You can move, or remove it, as needed.
            this.контактTableAdapter.Fill(this.phonebook_LabDataSet.Контакт);
            // TODO: This line of code loads data into the 'phonebook_LabDataSet.Действие' table. You can move, or remove it, as needed.
            this.действиеTableAdapter.Fill(this.phonebook_LabDataSet.Действие);
            // TODO: This line of code loads data into the 'phonebook_LabDataSet.Действие' table. You can move, or remove it, as needed.
            this.действиеTableAdapter.Fill(this.phonebook_LabDataSet.Действие);
            // TODO: This line of code loads data into the 'phonebook_LabDataSet.Контакт' table. You can move, or remove it, as needed.
            this.контактTableAdapter.Fill(this.phonebook_LabDataSet.Контакт);


            phonebook_LabDataSet.Контакт.Columns["Дата_изменения"].DefaultValue = DateTime.Now;

        }

        private void iD_КонтактTextBox_TextChanged(object sender, EventArgs e)
        {

        }

        private void iD_ПользLabel_Click(object sender, EventArgs e)
        {

        }

        private void контактDataGridView_CellFormatting(object sender, DataGridViewCellFormattingEventArgs e)
        {
        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void контактBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            try
            {
                this.Validate();
                this.контактBindingSource.EndEdit();
                this.tableAdapterManager.UpdateAll(this.phonebook_LabDataSet);
            }
            catch (Exception err)
            {
                MessageBox.Show(err.Message, "Ошибка", MessageBoxButtons.OK,
                    MessageBoxIcon.Error);
            }

        }

        private void toolStripButton7_Click(object sender, EventArgs e)
        {
            try
            {
                this.Validate();
                this.действиеBindingSource.EndEdit();
                this.tableAdapterManager.UpdateAll(this.phonebook_LabDataSet);
            }
            catch (Exception err)
            {
                MessageBox.Show(err.Message, "Ошибка", MessageBoxButtons.OK,
                    MessageBoxIcon.Error);
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int id = -1;
            if
           (((DataRowView)контактBindingSource.Current)["ID_Персо"].ToString() !="")
            {
                id = (int)(((DataRowView)контактBindingSource.Current)["ID_Персо"]);
            }
            id = PersonalForm.pd.ShowSelectForm(id);
            if (id >= 0)
            {
                MessageBox.Show(id.ToString());
                ((DataRowView)контактBindingSource.Current)["ID_Персо"] = id;
                контактBindingSource.EndEdit();
            }
        }

        private void ConctactForm_Shown(object sender, EventArgs e)
        {

        }

        private void действиеDataGridView_CellFormatting(object sender, DataGridViewCellFormattingEventArgs e)
        {
            if ((действиеDataGridView.Rows[e.RowIndex].Cells[
                "dataGridViewTextBoxColumn4"].Value == null) ||
                (действиеDataGridView.Rows[e.RowIndex].Cells[
                    "dataGridViewTextBoxColumn4"].Value.ToString() == ""))
                e.CellStyle.BackColor = Color.LightGreen;
            else
            {
                if (действиеDataGridView.Rows[e.RowIndex].Cells[
                    "dataGridViewTextBoxColumn4"].Value.ToString() == "Read")
                    e.CellStyle.BackColor = Color.SkyBlue;
                else if (действиеDataGridView.Rows[e.RowIndex].Cells[
                    "dataGridViewTextBoxColumn4"].Value.ToString() == "Add")
                    e.CellStyle.BackColor = Color.WhiteSmoke;
                else if (действиеDataGridView.Rows[e.RowIndex].Cells[
                    "dataGridViewTextBoxColumn4"].Value.ToString() == "Modify")
                    e.CellStyle.BackColor = Color.YellowGreen;
                else if (действиеDataGridView.Rows[e.RowIndex].Cells[
                    "dataGridViewTextBoxColumn4"].Value.ToString() == "Delete")
                    e.CellStyle.BackColor = Color.MediumVioletRed;
                else
                    e.CellStyle.BackColor = Color.Pink;
            }
        }

        private void фИО_ПерLabel_Click(object sender, EventArgs e)
        {

        }

        string GetSelectedFieldName()
        {
            return
           действиеDataGridView.Columns[действиеDataGridView.CurrentCell.ColumnIndex].DataPropertyName;
        }
        private void действиеDataGridView_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (String.Compare(GetSelectedFieldName(), "ID_Пользователь", false) == 0)
            {
                int idUserCurrent = -1;

                int.TryParse((((DataRowView)действиеBindingSource.Current)
                    ["ID_Пользователь"]).ToString(), out idUserCurrent);
                int idUser = UserForm.fd.ShowSelectForm(idUserCurrent);
                MessageBox.Show("ID_Пользователь = " + idUser.ToString());
                ((DataRowView)действиеBindingSource.Current)["ID_Пользователь"] = idUser;
                действиеBindingSource.EndEdit();
                действиеTableAdapter.Update(this.phonebook_LabDataSet);
                контактTableAdapter.Fill(this.phonebook_LabDataSet.Контакт);
            }
        }
    }
}
