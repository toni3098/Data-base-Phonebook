﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlTypes;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PhoneBook1
{
    public partial class UserForm : Form
    {
        public UserForm()
        {
            InitializeComponent();
        }

        private static UserForm f;
            public static UserForm fd
            {
                get
                {
                    if (f == null || f.IsDisposed)
                    {
                        f = new UserForm();
                    }
                    return f;
                }                    
            }

        
        private void UserForm_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'phonebook_LabDataSet.Пользователь' table. You can move, or remove it, as needed.
            this.пользовательTableAdapter.Fill(this.phonebook_LabDataSet.Пользователь);
            // TODO: This line of code loads data into the 'phonebook_LabDataSet.Пользователь' table. You can move, or remove it, as needed.
            this.пользовательTableAdapter.Fill(this.phonebook_LabDataSet.Пользователь);

        }

        string fileName = "";
        private void buttonOpenPhoto_Click(object sender, EventArgs e)
        {
            openFileDialogPhoto.Title = "Укажите файл для фото";
            if (openFileDialogPhoto.ShowDialog() == DialogResult.OK)
            {
                fileName = openFileDialogPhoto.FileName;
                фотоPictureBox.Image = new Bitmap(openFileDialogPhoto.FileName);
            }

            else fileName = "";
        }

        private void пользовательBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            try
            {
                this.Validate();
                this.пользовательBindingSource.EndEdit();
                this.tableAdapterManager.UpdateAll(this.phonebook_LabDataSet);
            }
            catch (Exception err)
            {
                MessageBox.Show(err.Message, "Ошибка", MessageBoxButtons.OK,
                    MessageBoxIcon.Error);
            }
        }

        int idCurrent = -1;
        public int ShowSelectForm(int idUser)
        {
            idCurrent = idUser;
            ShowDialog();
            return
           (int)((DataRowView)пользовательBindingSource.Current)["ID_Пользователь"];
        }

        private void UserForm_Shown(object sender, EventArgs e)
        {
            пользовательBindingSource.Position = пользовательBindingSource.Find("ID_Пользователь", idCurrent);
        }

        public void ShowForm()
        {
            пользовательBindingSource.Position = 0;
            Show();
            Activate();
        }
    }
}
